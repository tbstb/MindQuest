# Build MindQuest APK from an Android phone using GitHub Actions

## Recommended: GitHub CLI + Termux

You need a GitHub account, a browser, the project ZIP, and Termux (use its official distribution; avoid unknown APK mirrors). No PC is necessary.

1. Extract the ZIP into a directory accessible in Termux, or allow storage access with `termux-setup-storage`.
2. Install packages in Termux:

   ```sh
   pkg update
   pkg install git gh unzip
   ```

   If `gh` is not available in your current Termux repository, use Git over HTTPS or SSH to an existing private repo instead.

3. Assuming you saved the project ZIP to Android Downloads and it contains files at the ZIP root:

   ```sh
   termux-setup-storage
   mkdir -p "$HOME/mindquest"
   unzip "$HOME/storage/downloads/MindQuestAndroid_Source.zip" -d "$HOME/mindquest"
   cd "$HOME/mindquest"
   git init
   git branch -M main
   git config user.name "YOUR_GITHUB_USERNAME"
   git config user.email "YOUR_GITHUB_EMAIL"
   git add .
   git commit -m "Initial native MindQuest Android project"
   gh auth login
   gh repo create MindQuest --private --source=. --remote=origin --push
   ```

   GitHub CLI login uses a GitHub-hosted flow; never share passwords or authentication tokens in chat.

4. In a browser, open your GitHub repo and select **Actions**. Pushing to main should start `Build MindQuest Android APK` automatically.
5. Open the newest **successful** run, find the `MindQuest-debug-APK` artifact, download it and extract `app-debug.apk`.
6. Install the APK on your Android device. On first install, your phone may ask permission to install apps from your file browser.

This is a **debug APK** signed by Android's local testing key, not a production-signed Play Store build. The workflow builds with Android SDK 35, JDK 17, AGP 8.7.3 and Gradle 8.9.

## If GitHub Actions fails

Open Actions > failed run > `build-debug-apk` > `Assemble debug APK`. The compiler errors will name the affected file and line. Fix those errors in your repo and push another commit. In this environment, this project was NOT compiled or tested on an emulator, so successful build cannot be promised.

## Signed release notes

For a release: create and securely store your own signing keystore (never commit the key or passwords into GitHub), configure Android Gradle signing using encrypted CI secrets, perform real-device QA and release reviews, then assemble the signed release variant. This ZIP does not contain any private signing key.
