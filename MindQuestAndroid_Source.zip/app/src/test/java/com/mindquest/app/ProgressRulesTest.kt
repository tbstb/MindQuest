package com.mindquest.app

import com.mindquest.app.data.QuestEntity
import com.mindquest.app.model.completionKey
import com.mindquest.app.model.levelForXp
import com.mindquest.app.model.levelProgress
import com.mindquest.app.model.questIsDone
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class ProgressRulesTest {
    @Test fun levelBoundary() {
        assertEquals(1,levelForXp(0))
        assertEquals(1,levelForXp(249))
        assertEquals(2,levelForXp(250))
        assertEquals(5,levelForXp(1000))
        assertEquals(0.5f,levelProgress(125),0.00001f)
    }
    @Test fun dailyAndOnceKeys() {
        val daily=QuestEntity(title="Read")
        val today=LocalDate.of(2026,11,11)
        assertEquals("2026-11-11",completionKey(daily,today))
        assertEquals("2026-11-12",completionKey(daily,today.plusDays(1)))
        val once=daily.copy(repeat="Once")
        assertEquals("FOREVER",completionKey(once,today))
        assertEquals("FOREVER",completionKey(once,today.plusYears(2)))
    }
    @Test fun weeklyKeyRespectsIsoWeekYear() {
        val weekly=QuestEntity(title="Water plant",repeat="Weekly")
        assertEquals("W-2026-53",completionKey(weekly,LocalDate.of(2027,1,1)))
    }
    @Test fun completionDefaultsToUnchecked() {
        assertFalse(questIsDone(QuestEntity(title="Journal")))
        assertTrue(questIsDone(QuestEntity(title="Once",repeat="Once",completedKey="FOREVER")))
    }
}
