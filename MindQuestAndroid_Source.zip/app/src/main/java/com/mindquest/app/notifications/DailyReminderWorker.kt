package com.mindquest.app.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.mindquest.app.R

class DailyReminderWorker(appContext:Context, params:WorkerParameters):CoroutineWorker(appContext,params) {
    override suspend fun doWork(): Result {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
                applicationContext,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) return Result.success()
        val channelId="mindquest_gentle_reminder"
        val manager=applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(channelId,"Gentle reminders",NotificationManager.IMPORTANCE_LOW))
        val notification=NotificationCompat.Builder(applicationContext,channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("A peaceful moment is here")
            .setContentText("When you're ready, MindQuest is here for a quiet pause.")
            .setAutoCancel(true).build()
        manager.notify(101,notification)
        return Result.success()
    }
}
