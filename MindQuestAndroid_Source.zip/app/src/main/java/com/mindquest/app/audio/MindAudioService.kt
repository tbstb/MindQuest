package com.mindquest.app.audio

import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Media3 manages the persistent playback notification and lock-screen transport controls. */
class MindAudioService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private var player: ExoPlayer? = null

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),true)
            repeatMode = Player.REPEAT_MODE_ONE
        }
        mediaSession = MediaSession.Builder(this,player!!).build()
    }
    override fun onGetSession(controllerInfo:MediaSession.ControllerInfo): MediaSession? = mediaSession
    override fun onTaskRemoved(rootIntent: Intent?) {
        if(player?.isPlaying != true) stopSelf()
    }
    override fun onDestroy() {
        mediaSession?.release()
        mediaSession=null
        player?.release()
        player=null
        super.onDestroy()
    }
}
