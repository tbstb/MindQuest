package com.mindquest.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

val Navy=Color(0xFF101426)
val Charcoal=Color(0xFF171924)
val Cosmic=Color(0xFF241B3D)
val Panel=Color(0xFF292744)
val Indigo=Color(0xFF393052)
val PanelEdge=Color(0xFF655A85)
val Green=Color(0xFF75E06B)
val Gold=Color(0xFFF5C65D)
val Cyan=Color(0xFF68DBEB)
val Lavender=Color(0xFFB49AF0)
val Coral=Color(0xFFFF7979)
val Cream=Color(0xFFF5EDDA)
val Muted=Color(0xFFB3AFC4)
val PixelShape=RoundedCornerShape(5.dp)

private val colorScheme=darkColorScheme(
    primary=Lavender,onPrimary=Navy,secondary=Green,onSecondary=Navy,
    tertiary=Gold,background=Navy,onBackground=Cream,
    surface=Panel,onSurface=Cream,surfaceVariant=Indigo,onSurfaceVariant=Muted,
    outline=PanelEdge,error=Coral
)

@Composable fun MindQuestTheme(content:@Composable ()->Unit) {
    MaterialTheme(colorScheme=colorScheme,typography=Typography(
        headlineLarge=Typography().headlineLarge.copy(fontFamily=FontFamily.Monospace,fontWeight=FontWeight.Black,color=Cream),
        headlineMedium=Typography().headlineMedium.copy(fontFamily=FontFamily.Monospace,fontWeight=FontWeight.Bold,color=Cream),
        titleLarge=Typography().titleLarge.copy(fontFamily=FontFamily.Monospace,fontWeight=FontWeight.Bold,color=Cream),
        titleMedium=Typography().titleMedium.copy(fontFamily=FontFamily.Monospace,fontWeight=FontWeight.Bold,color=Cream),
        bodyMedium=Typography().bodyMedium.copy(color=Cream),
        bodySmall=Typography().bodySmall.copy(color=Muted)
    ),content=content)
}

@Composable fun PixelPanel(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit) {
    Column(modifier=modifier
        .border(2.dp,PanelEdge,PixelShape)
        .background(Panel,PixelShape)
        .padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp),content=content)
}

@Composable fun PixelTitle(text:String,modifier:Modifier=Modifier,color:Color=Cream,size:TextUnit=18.sp) {
    Text(text,modifier=modifier,color=color,fontFamily=FontFamily.Monospace,
        fontWeight=FontWeight.Black,fontSize=size,letterSpacing=.1.sp)
}

@Composable fun PixelButton(
    label:String,onClick:()->Unit,modifier:Modifier=Modifier,
    primary:Boolean=true,enabled:Boolean=true
) {
    Button(onClick=onClick,modifier=modifier.heightIn(min=44.dp),enabled=enabled,
        shape=PixelShape,border=BorderStroke(2.dp,if(primary)Color(0xFFA3F59E) else PanelEdge),
        contentPadding=PaddingValues(horizontal=14.dp,vertical=7.dp),
        colors=ButtonDefaults.buttonColors(
            containerColor=if(primary)Green else Indigo,
            contentColor=if(primary)Navy else Cream,
            disabledContainerColor=PanelEdge,disabledContentColor=Muted)) {
        Text(label,fontFamily=FontFamily.Monospace,fontWeight=FontWeight.Bold,fontSize=12.sp)
    }
}

@Composable fun XpMeter(progress:Float,modifier:Modifier=Modifier) {
    Column(modifier=modifier) {
        Box(Modifier.fillMaxWidth().height(12.dp).border(1.dp,PanelEdge,PixelShape).background(Navy,PixelShape)) {
            Box(Modifier.fillMaxWidth(progress.coerceIn(0f,1f)).fillMaxHeight().background(Green,PixelShape))
        }
    }
}
@Composable fun Tag(label:String,color:Color=Lavender,modifier:Modifier=Modifier) {
    Box(modifier.border(1.dp,color,PixelShape).background(color.copy(alpha=.12f),PixelShape)
        .padding(horizontal=7.dp,vertical=3.dp)) {
        Text(label,color=color,fontSize=10.sp,fontFamily=FontFamily.Monospace)
    }
}
