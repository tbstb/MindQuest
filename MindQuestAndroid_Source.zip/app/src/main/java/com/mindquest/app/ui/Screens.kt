package com.mindquest.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import com.mindquest.app.ActiveMeditation
import com.mindquest.app.R
import com.mindquest.app.data.*
import com.mindquest.app.model.*
import java.time.LocalTime

@Composable fun PageColumn(content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        .padding(horizontal=14.dp,vertical=12.dp),verticalArrangement=Arrangement.spacedBy(14.dp),content=content)
}

@Composable fun SectionHeading(title:String,subtitle:String?=null) {
    Column(verticalArrangement=Arrangement.spacedBy(2.dp)) {
        PixelTitle(title)
        if(subtitle!=null)Text(subtitle,color=Muted,fontSize=12.sp)
    }
}

@Composable fun HeroHeader(hero:HeroEntity) {
    PixelPanel(Modifier.fillMaxWidth()) {
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            Image(painterResource(avatars[hero.avatar.coerceIn(0,5)]),"Your pixel hero",Modifier.size(66.dp))
            Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                PixelTitle("Hi, ${hero.name}!",size=16.sp)
                Text("LV. ${levelForXp(hero.xp)}  ·  ${hero.xp} XP",color=Cyan,fontSize=12.sp)
                XpMeter(levelProgress(hero.xp))
                Text("${hero.xp%250} / 250 XP to next level",color=Muted,fontSize=10.sp)
            }
            Column(horizontalAlignment=Alignment.End) {
                Text("🟡 ${hero.gold}",color=Gold,fontWeight=FontWeight.Bold)
                Text("GOLD",fontSize=9.sp,color=Muted)
            }
        }
    }
}

@Composable fun SceneBanner(drawable:Int,title:String,description:String?=null,height:Dp=170.dp,modifier:Modifier=Modifier) {
    Box(modifier.fillMaxWidth().height(height).border(2.dp,PanelEdge,PixelShape).clip(PixelShape)) {
        Image(painterResource(drawable),title,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            listOf(Color.Transparent,Color.Transparent,Navy.copy(alpha=.85f)))))
        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            PixelTitle(title,size=16.sp)
            if(description!=null)Text(description,color=Cream,fontSize=11.sp)
        }
    }
}

@Composable fun HomeScreen(
    hero:HeroEntity,quests:List<QuestEntity>,logs:List<ActivityLogEntity>,
    onQuest:(Long)->Unit,onUndo:(Long)->Unit,onMeditate:()->Unit,
    onBreathing:()->Unit,onJournal:()->Unit,onSleep:()->Unit,
    onQuests:()->Unit,onAdventure:()->Unit
) {
    val hour=LocalTime.now().hour
    val background=when(hour) {
        in 5..10 -> R.drawable.scene_meadow
        in 11..16 -> R.drawable.scene_forest
        in 17..20 -> R.drawable.scene_lake
        else -> R.drawable.scene_village
    }
    val greeting=when(hour){ in 5..11->"Good morning";in 12..17->"Good afternoon";else->"Peaceful evening" }
    val completed=quests.count(::questIsDone)
    PageColumn {
        HeroHeader(hero)
        SceneBanner(background,"$greeting, Traveler", "Your cozy adventure continues")
        PixelPanel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                PixelTitle("DAILY QUEST BOARD",Modifier.weight(1f),size=15.sp)
                TextButton(onClick=onQuests){Text("View all",color=Cyan,fontSize=11.sp)}
            }
            Text("$completed / ${quests.size} completed",color=Muted,fontSize=12.sp)
            XpMeter(if(quests.isEmpty())0f else completed.toFloat()/quests.size)
            quests.take(4).forEach { q ->
                QuestCheckRow(q,onComplete={onQuest(q.id)},onUndo={onUndo(q.id)},compact=true)
            }
            if(quests.isEmpty())Text("Your quest board is clear. Add a quest to get started!",color=Muted)
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            QuickAction("Meditate",Icons.Filled.Spa,Green,onMeditate,Modifier.weight(1f))
            QuickAction("Breathe",Icons.Filled.Air,Cyan,onBreathing,Modifier.weight(1f))
            QuickAction("Journal",Icons.Filled.EditNote,Lavender,onJournal,Modifier.weight(1f))
            QuickAction("Sleep",Icons.Filled.Bedtime,Gold,onSleep,Modifier.weight(1f))
        }
        SectionHeading("TODAY'S MEDITATION","Five minutes of gentle focus")
        FeaturedMeditation(Catalog.meditations.first(),onMeditate)
        PixelPanel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Filled.AutoAwesome,null,tint=Gold)
                Spacer(Modifier.width(7.dp))
                PixelTitle("YOUR JOURNEY",size=15.sp)
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) {
                MiniStat("${hero.mindfulMinutes}","MINUTES")
                MiniStat("${hero.questsCompleted}","QUESTS")
                MiniStat("${hero.meditationsCompleted}","SESSIONS")
            }
            PixelButton("EXPLORE WORLD",onAdventure,Modifier.fillMaxWidth(),primary=false)
        }
        Text("MindQuest is a gentle companion, not a medical treatment. All activities are optional.",color=Muted,fontSize=11.sp)
    }
}

@Composable private fun QuickAction(title:String,icon:androidx.compose.ui.graphics.vector.ImageVector,color:Color,
                                     onClick:()->Unit,modifier:Modifier=Modifier) {
    Column(modifier.border(1.dp,PanelEdge,PixelShape).background(Panel,PixelShape)
        .clickable(onClick=onClick).padding(vertical=12.dp,horizontal=2.dp),
        horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(6.dp)) {
        Icon(icon,title,tint=color,modifier=Modifier.size(26.dp))
        Text(title,color=Cream,fontSize=11.sp,maxLines=1)
    }
}
@Composable fun MiniStat(value:String,label:String) {
    Column(horizontalAlignment=Alignment.CenterHorizontally) {
        PixelTitle(value,color=Gold,size=19.sp)
        Text(label,fontSize=9.sp,color=Muted)
    }
}

@Composable fun QuestCheckRow(q:QuestEntity,onComplete:()->Unit,onUndo:()->Unit,compact:Boolean=false,
                              onEdit:(()->Unit)?=null) {
    val done=questIsDone(q)
    Row(Modifier.fillMaxWidth().border(1.dp,PanelEdge,PixelShape).background(Indigo,PixelShape)
        .padding(5.dp),verticalAlignment=Alignment.CenterVertically) {
        Checkbox(checked=done,onCheckedChange={if(it)onComplete() else onUndo()},
            colors=CheckboxDefaults.colors(checkedColor=Green,uncheckedColor=Muted,checkmarkColor=Navy))
        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)) {
            Text(q.title,color=if(done)Muted else Cream,fontSize=if(compact)12.sp else 14.sp,
                fontWeight=FontWeight.SemiBold)
            Text("+${q.xp} XP  ·  🟡${q.gold}  ·  ${q.repeat}",fontSize=10.sp,color=if(done)Muted else Gold)
            if(!compact && q.detail.isNotBlank())Text(q.detail,color=Muted,fontSize=11.sp)
        }
        if(onEdit!=null) IconButton(onClick=onEdit) {
            Icon(Icons.Filled.Edit,"Edit quest",Modifier.size(19.dp),tint=Lavender)
        }
    }
}

@Composable fun QuestScreen(quests:List<QuestEntity>,onComplete:(Long)->Unit,onUndo:(Long)->Unit,
                            onSave:(QuestEntity)->Unit,onDelete:(Long)->Unit) {
    var filter by remember { mutableStateOf("All") }
    var editing by remember { mutableStateOf<QuestEntity?>(null) }
    var editorVisible by remember { mutableStateOf(false) }
    val filtered=quests.filter {
        when(filter){ "Completed"->questIsDone(it);"Daily","Weekly","Once"->it.repeat==filter;else->true }
    }
    val completed=quests.count(::questIsDone)
    PageColumn {
        Row(verticalAlignment=Alignment.CenterVertically) {
            SectionHeading("QUEST BOARD","Make real life a cozy adventure")
            Spacer(Modifier.weight(1f))
            IconButton(onClick={editing=null;editorVisible=true}){
                Icon(Icons.Filled.AddCircle,"Add quest",tint=Green,modifier=Modifier.size(31.dp))
            }
        }
        PixelPanel(Modifier.fillMaxWidth()) {
            Text("QUEST PROGRESS",color=Cyan,fontSize=11.sp)
            XpMeter(if(quests.isEmpty())0f else completed.toFloat()/quests.size)
            Text("$completed / ${quests.size} currently checked",color=Muted,fontSize=12.sp)
            Text("Rewards are earned once per quest period, even if a checkmark is undone.",color=Muted,fontSize=10.sp)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            listOf("All","Daily","Weekly","Once","Completed").forEach { f ->
                FilterChip(selected=filter==f,onClick={filter=f},label={Text(f)})
            }
        }
        filtered.forEach { q ->
            QuestCheckRow(q,onComplete={onComplete(q.id)},onUndo={onUndo(q.id)},onEdit={editing=q;editorVisible=true})
        }
        if(filtered.isEmpty())Text("No quests in this category yet.",color=Muted,modifier=Modifier.padding(15.dp))
        PixelButton("+ CREATE A QUEST",{editing=null;editorVisible=true},Modifier.fillMaxWidth())
    }
    if(editorVisible) QuestEditorDialog(editing,onDismiss={editorVisible=false},onSave={
        onSave(it);editorVisible=false
    },onDelete=editing?.let { q -> { onDelete(q.id); editorVisible=false } })
}

@Composable private fun QuestEditorDialog(q:QuestEntity?,onDismiss:()->Unit,
                                         onSave:(QuestEntity)->Unit,onDelete:(()->Unit)?) {
    var title by remember(q?.id) { mutableStateOf(q?.title ?: "") }
    var details by remember(q?.id) { mutableStateOf(q?.detail ?: "") }
    var repeat by remember(q?.id) { mutableStateOf(q?.repeat ?: "Daily") }
    var category by remember(q?.id) { mutableStateOf(q?.category ?: "Wellness") }
    var minutes by remember(q?.id) { mutableStateOf((q?.minutes ?: 10).toString()) }
    var difficulty by remember(q?.id) { mutableStateOf(if((q?.xp ?: 60)>=120)"Hard" else if((q?.xp ?: 60)>=80)"Medium" else "Easy") }
    var confirmDelete by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest=onDismiss,containerColor=Panel,
        title={PixelTitle(if(q==null)"NEW QUEST" else "EDIT QUEST",size=17.sp)},
        text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title,{title=it.take(80)},label={Text("Quest name")},singleLine=true)
            OutlinedTextField(details,{details=it.take(200)},label={Text("Description")},maxLines=3)
            Text("Repeat",color=Muted)
            Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                listOf("Daily","Weekly","Once").forEach { v ->
                    FilterChip(selected=v==repeat,onClick={repeat=v},label={Text(v,fontSize=11.sp)})
                }
            }
            Text("Category",color=Muted)
            Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                listOf("Wellness","Learning","Mindfulness","Personal").forEach { v ->
                    FilterChip(selected=v==category,onClick={category=v},label={Text(v,fontSize=11.sp)})
                }
            }
            OutlinedTextField(minutes,{minutes=it.filter(Char::isDigit).take(3)},label={Text("Estimated minutes")},
                keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
            Text("Difficulty and rewards",color=Muted)
            Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                listOf("Easy","Medium","Hard").forEach { v ->
                    FilterChip(selected=v==difficulty,onClick={difficulty=v},label={Text(v,fontSize=11.sp)})
                }
            }
            Text(when(difficulty){"Hard"->"+120 XP / +60 gold";"Medium"->"+80 XP / +40 gold";else->"+60 XP / +30 gold"},
                color=Gold,fontSize=12.sp)
            if(onDelete!=null) {
                if(confirmDelete) {
                    Text("Delete this quest permanently?",color=Coral)
                    TextButton(onClick=onDelete){Text("Yes, delete",color=Coral)}
                } else TextButton(onClick={confirmDelete=true}) {Text("Delete quest",color=Coral)}
            }
        }},
        confirmButton={TextButton(enabled=title.isNotBlank(),onClick={
            val (xp,gold)=when(difficulty){"Hard"->120 to 60;"Medium"->80 to 40;else->60 to 30}
            onSave((q?:QuestEntity(title=title)).copy(
                title=title,detail=details,category=category,repeat=repeat,
                minutes=(minutes.toIntOrNull()?:10).coerceIn(1,240),xp=xp,gold=gold))
        }){Text("Save",color=Green)}},
        dismissButton={TextButton(onClick=onDismiss){Text("Cancel",color=Muted)}})
}

@Composable fun FeaturedMeditation(content:Meditation,onStart:()->Unit) {
    PixelPanel(Modifier.fillMaxWidth()) {
        Image(painterResource(content.image),content.title,Modifier.fillMaxWidth().height(140.dp),contentScale=ContentScale.Crop)
        Row(verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                PixelTitle(content.title,size=15.sp)
                Text("${content.minutes} min · ${content.experience}",color=Muted,fontSize=11.sp)
            }
            PixelButton("▶ START",onStart)
        }
        Text(content.description,color=Muted,fontSize=12.sp)
    }
}

@Composable fun MeditationScreen(favorites:Set<String>,selectedCategory:String,
                                onCategoryChange:(String)->Unit,onFavorite:(String)->Unit,
                                onStart:(Meditation)->Unit,onBreathing:()->Unit) {
    val content=Catalog.meditations.filter { selectedCategory=="All" || it.category==selectedCategory ||
        (selectedCategory=="Mindfulness" && it.category=="Daily") ||
        (selectedCategory=="Favorites" && it.id in favorites) }
    PageColumn {
        SectionHeading("MEDITATE & REST","A little peace, whenever you need it")
        SceneBanner(R.drawable.scene_garden,"A garden of quiet moments", "Original offline ambience included",height=145.dp)
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
            (listOf("Favorites")+Catalog.categories).forEach { cat ->
                FilterChip(selected=cat==selectedCategory,onClick={onCategoryChange(cat)},label={Text(cat)})
            }
        }
        PixelPanel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Filled.Air,null,tint=Cyan,modifier=Modifier.size(35.dp))
                Column(Modifier.weight(1f)) {
                    PixelTitle("MAGICAL BREATHING",size=14.sp)
                    Text("Follow a gentle breathing orb",color=Muted,fontSize=11.sp)
                }
                PixelButton("OPEN",onBreathing,primary=false)
            }
        }
        content.forEach { c ->
            MeditationCard(c,c.id in favorites,onFavorite={onFavorite(c.id)},onStart={onStart(c)})
        }
        if(content.isEmpty())Text(if(selectedCategory=="Favorites")
            "Tap the heart on a session to save it here." else "No sessions in this category yet.",color=Muted)
        Text("All included audio is original and stored on your device. Guidance uses your Android voice engine.",color=Muted,fontSize=11.sp)
    }
}

@Composable private fun MeditationCard(c:Meditation,isFavorite:Boolean,onFavorite:()->Unit,onStart:()->Unit) {
    Row(Modifier.fillMaxWidth().border(2.dp,PanelEdge,PixelShape).background(Panel,PixelShape)
        .padding(8.dp),verticalAlignment=Alignment.CenterVertically,
        horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        Image(painterResource(c.image),c.title,Modifier.size(95.dp),contentScale=ContentScale.Crop)
        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(4.dp)) {
            Text(c.title,color=Cream,fontWeight=FontWeight.Bold,fontSize=14.sp)
            Text(c.description,maxLines=2,color=Muted,fontSize=11.sp)
            Text("${c.minutes} min · ${c.experience} · +${c.xp} XP",color=Green,fontSize=10.sp)
            Row(verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Filled.OfflinePin,null,Modifier.size(14.dp),tint=Cyan)
                Text(" Offline",color=Cyan,fontSize=10.sp)
                Spacer(Modifier.weight(1f))
                IconButton(onClick=onFavorite,modifier=Modifier.size(33.dp)) {
                    Icon(if(isFavorite)Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        "Toggle favorite",tint=if(isFavorite)Coral else Muted)
                }
                IconButton(onClick=onStart,modifier=Modifier.size(40.dp)) {
                    Icon(Icons.Filled.PlayCircle,"Start meditation",tint=Green,modifier=Modifier.size(32.dp))
                }
            }
        }
    }
}

@Composable fun MeditationPlayer(session:ActiveMeditation,playing:Boolean,
                                 onBack:()->Unit,onPause:()->Unit,onStop:()->Unit,
                                 onVoice:()->Boolean,onSeekAmbient:(Float)->Unit,onFinish:()->Unit) {
    val c=session.content
    var ambientSeek by remember(c.id) { mutableFloatStateOf(0f) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=onBack) {Icon(Icons.Filled.ArrowBack,"Back to app",tint=Cream)}
            Spacer(Modifier.weight(1f))
            Tag(if(c.sleep)"SLEEP MODE" else "MEDITATION",Cyan)
            IconButton(onClick=onStop) {Icon(Icons.Filled.Close,"End session",tint=Muted)}
        }
        Image(painterResource(c.image),c.title,Modifier.fillMaxWidth().height(265.dp)
            .border(2.dp,PanelEdge,PixelShape),contentScale=ContentScale.Crop)
        if(session.complete) {
            PixelTitle("✦ QUEST COMPLETE ✦",color=Green,size=20.sp)
            Text("+${c.xp} XP  ·  +${c.gold} gold",color=Gold,fontSize=18.sp,fontWeight=FontWeight.Bold)
            Text("Thank you for making time to rest.",color=Muted)
            PixelButton("CONTINUE ADVENTURE",onFinish,Modifier.fillMaxWidth())
        } else {
            PixelTitle(c.title,size=21.sp)
            Text("${c.minutes} min · ${c.experience} · Android voice guide",color=Muted,fontSize=12.sp)
            Text(c.description,color=Cream,fontSize=13.sp,textAlign=TextAlign.Center)
            LinearProgressIndicator(progress={session.elapsedMs/(c.minutes*60_000f)},
                modifier=Modifier.fillMaxWidth().height(9.dp),color=Green,trackColor=Indigo)
            val elapsed=(session.elapsedMs/1000).toInt()
            Text("%02d:%02d / %02d:00".format(elapsed/60,elapsed%60,c.minutes),
                color=Cyan,fontSize=13.sp)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center,
                verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick={ambientSeek=(ambientSeek-.15f).coerceAtLeast(0f);onSeekAmbient(ambientSeek)}) {
                    Icon(Icons.Filled.Replay10,"Rewind audio 10 seconds",tint=Muted,modifier=Modifier.size(30.dp))
                }
                Spacer(Modifier.width(14.dp))
                IconButton(onClick=onPause,modifier=Modifier.size(76.dp)
                    .background(Indigo,CircleShape).border(2.dp,Lavender,CircleShape)) {
                    Icon(if(playing)Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        if(playing)"Pause" else "Play",tint=Green,modifier=Modifier.size(48.dp))
                }
                Spacer(Modifier.width(14.dp))
                IconButton(onClick={ambientSeek=(ambientSeek+.15f).coerceAtMost(1f);onSeekAmbient(ambientSeek)}) {
                    Icon(Icons.Filled.Forward10,"Forward audio 10 seconds",tint=Muted,modifier=Modifier.size(30.dp))
                }
            }
            Text("AMBIENT AUDIO POSITION",color=Muted,fontSize=10.sp)
            Slider(value=ambientSeek,onValueChange={ambientSeek=it},onValueChangeFinished={onSeekAmbient(ambientSeek)},
                colors=SliderDefaults.colors(thumbColor=Lavender,activeTrackColor=Cyan))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                PixelButton("VOICE ON / OFF",{onVoice()},primary=false)
                PixelButton("END EARLY",onStop,primary=false)
            }
            Text("Ending early never causes a penalty. Full-session rewards are recorded once.",
                fontSize=11.sp,color=Muted,textAlign=TextAlign.Center)
        }
    }
}
