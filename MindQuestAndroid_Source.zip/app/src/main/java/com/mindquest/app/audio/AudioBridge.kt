package com.mindquest.app.audio

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Controller survives screen navigation; audio is actually played by the media service. */
class AudioBridge(private val context:Context) {
    private val _playing=MutableStateFlow(false)
    val playing:StateFlow<Boolean> = _playing
    private val _connected=MutableStateFlow(false)
    val connected:StateFlow<Boolean> = _connected
    private var controller:MediaController?=null
    private var connection:ListenableFuture<MediaController>?=null
    private var pending:Pair<Int,String>?=null
    private var desiredVolume:Float=1f
    private val listener=object:Player.Listener {
        override fun onIsPlayingChanged(isPlaying:Boolean) { _playing.value=isPlaying }
    }
    init {
        val token=SessionToken(context,ComponentName(context,MindAudioService::class.java))
        connection=MediaController.Builder(context,token).buildAsync().also { future ->
            future.addListener({
                try {
                    controller=future.get()
                    controller?.addListener(listener)
                    _connected.value=true
                    pending?.let { (resource,title) -> play(resource,title) }
                    pending=null
                } catch (_:Exception) { _connected.value=false }
            },ContextCompat.getMainExecutor(context))
        }
    }
    fun play(resId:Int,title:String) {
        val c=controller
        if(c==null) { pending=resId to title;return }
        val uri=Uri.parse("android.resource://${context.packageName}/$resId")
        val item=MediaItem.Builder().setUri(uri).setMediaMetadata(
            MediaMetadata.Builder().setTitle(title).setArtist("MindQuest original ambience").build()).build()
        c.setMediaItem(item);c.setVolume(desiredVolume);c.prepare();c.play()
    }
    fun setVolume(v:Float) { desiredVolume=v.coerceIn(0f,1f);controller?.setVolume(desiredVolume) }
    fun pause() { controller?.pause() }
    fun resume() { controller?.play() }
    fun stop() { pending=null;controller?.stop();controller?.clearMediaItems();_playing.value=false;setVolume(1f) }
    fun seekAmbient(fraction:Float) {
        val c=controller?:return
        val duration=c.duration
        if(duration>0) c.seekTo((duration*fraction.coerceIn(0f,1f)).toLong())
    }
    fun release() {
        controller?.removeListener(listener)
        connection?.let { MediaController.releaseFuture(it) }
        controller=null
    }
}
