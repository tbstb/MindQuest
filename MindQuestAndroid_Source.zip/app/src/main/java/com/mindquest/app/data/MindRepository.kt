package com.mindquest.app.data

import android.content.Context
import androidx.room.withTransaction
import androidx.work.*
import com.mindquest.app.model.Catalog
import com.mindquest.app.model.Shop
import com.mindquest.app.model.completionKey
import com.mindquest.app.model.questIsDone
import com.mindquest.app.notifications.DailyReminderWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class MindRepository(private val context: Context) {
    val db = MindQuestDatabase.get(context)
    private val dao = db.dao()
    val settings = SettingsStore(context)
    val hero = dao.heroFlow()
    val quests = dao.questFlow()
    val activityLogs = dao.logFlow()
    val journal = dao.journalFlow()
    val inventory = dao.inventoryFlow()
    val favorites = dao.favoritesFlow()
    val preferences = settings.flow

    suspend fun seedIfNecessary() = db.withTransaction {
        if (dao.hero() == null) {
            dao.putHero(HeroEntity())
            if (dao.questCount() == 0) dao.addQuests(*Catalog.questSeeds.toTypedArray())
            dao.putInventory(InventoryEntity("blossom", 1, true))
        }
    }
    suspend fun setIdentity(name: String, avatar: Int) = db.withTransaction {
        val old = dao.hero() ?: HeroEntity()
        dao.putHero(old.copy(name=name.trim().take(24).ifEmpty { "Traveler" }, avatar=avatar.coerceIn(0,5)))
    }
    suspend fun markQuest(id: Long): String = db.withTransaction {
        val quest = dao.quest(id) ?: return@withTransaction "Quest no longer exists"
        val key = completionKey(quest)
        if (questIsDone(quest)) return@withTransaction "Already completed"
        val reward = quest.lastRewardKey != key
        dao.updateQuest(quest.copy(completedKey=key, lastRewardKey=if(reward)key else quest.lastRewardKey))
        if (reward) {
            dao.insertActivity(ActivityLogEntity("quest-${quest.id}-$key", "quest-${quest.id}",
                "quest", 0, System.currentTimeMillis(), quest.xp, quest.gold))
            val h = dao.hero() ?: HeroEntity()
            dao.putHero(h.copy(xp=h.xp+quest.xp, gold=h.gold+quest.gold,
                totalGoldEarned=h.totalGoldEarned+quest.gold,
                questsCompleted=h.questsCompleted+1,
                focusPoints=h.focusPoints + if(quest.category=="Learning") 1 else 0,
                wisdomPoints=h.wisdomPoints + if(quest.category=="Personal") 1 else 0))
            "Quest complete! +${quest.xp} XP · +${quest.gold} gold"
        } else "Quest checked! Today's reward was already collected."
    }
    suspend fun undoQuest(id:Long): String = db.withTransaction {
        val q=dao.quest(id) ?: return@withTransaction "Quest missing"
        dao.updateQuest(q.copy(completedKey=null))
        "Completion undone. Rewards stay recorded to prevent duplicates."
    }
    suspend fun saveQuest(quest: QuestEntity) = db.withTransaction {
        if (quest.id == 0L) dao.addQuests(quest.copy(
            title=quest.title.trim().take(80), detail=quest.detail.take(200)))
        else {
            val old=dao.quest(quest.id) ?: return@withTransaction
            dao.updateQuest(quest.copy(
                title=quest.title.trim().take(80), detail=quest.detail.take(200),
                completedKey=old.completedKey, lastRewardKey=old.lastRewardKey,
                createdAt=old.createdAt))
        }
    }
    suspend fun removeQuest(id:Long) = dao.deleteQuest(id)

    /** The UUID token is unique per started session. Room IGNORE + transaction makes reward idempotent. */
    suspend fun completeActivity(token:String, contentId:String, kind:String, mins:Int, xp:Int, gold:Int): Boolean = db.withTransaction {
        val inserted=dao.insertActivity(ActivityLogEntity(token,contentId,kind,mins,System.currentTimeMillis(),xp,gold))
        if (inserted == -1L) return@withTransaction false
        val h=dao.hero() ?: HeroEntity()
        dao.putHero(h.copy(
            xp=h.xp+xp, gold=h.gold+gold, totalGoldEarned=h.totalGoldEarned+gold,
            meditationsCompleted=h.meditationsCompleted + if(kind=="meditation") 1 else 0,
            breathingCompleted=h.breathingCompleted + if(kind=="breathing") 1 else 0,
            mindfulMinutes=h.mindfulMinutes+mins,
            calmPoints=h.calmPoints+1
        ))
        true
    }

    suspend fun purchase(itemId:String):String = db.withTransaction {
        val item=Shop.items.firstOrNull { it.id==itemId } ?: return@withTransaction "Item unavailable"
        val hero=dao.hero() ?: HeroEntity()
        if(hero.gold<item.price) return@withTransaction "Not enough gold yet"
        dao.putHero(hero.copy(gold=hero.gold-item.price))
        val existing=dao.inventory(itemId)
        dao.putInventory(existing?.copy(quantity=existing.quantity+1) ?: InventoryEntity(itemId))
        "${item.name} added to inventory!"
    }
    suspend fun equip(itemId:String):String = db.withTransaction {
        if(dao.inventory(itemId)==null) return@withTransaction "Item not owned"
        dao.unequipAll()
        dao.equip(itemId)
        "Equipped!"
    }
    suspend fun addJournal(mood:String, note:String) {
        dao.insertJournal(JournalEntity(mood=mood.take(30),note=note.take(6000)))
    }
    suspend fun deleteJournal(id:Long) = dao.deleteJournal(id)
    suspend fun toggleFavorite(id:String) = db.withTransaction {
        if (dao.favorite(id)==null) dao.addFavorite(FavoriteEntity(id)) else dao.removeFavorite(id)
    }
    suspend fun finishOnboarding(goals:List<String> = emptyList(), experience:String = "New to meditation",
                                    duration:Int = 5,world:String = "Moonlight Village") =
        settings.completeOnboarding(goals,experience,duration,world)
    suspend fun updateReminders(v:Boolean) {
        settings.setReminders(v)
        val manager=WorkManager.getInstance(context)
        if(v) {
            val request=PeriodicWorkRequestBuilder<DailyReminderWorker>(24,TimeUnit.HOURS)
                .setInitialDelay(12,TimeUnit.HOURS).build()
            manager.enqueueUniquePeriodicWork("mindquest-daily-gentle-reminder",ExistingPeriodicWorkPolicy.UPDATE,request)
        } else manager.cancelUniqueWork("mindquest-daily-gentle-reminder")
    }
    suspend fun resetLocalData() {
        withContext(Dispatchers.IO) { db.clearAllTables() }
        seedIfNecessary()
    }
}
