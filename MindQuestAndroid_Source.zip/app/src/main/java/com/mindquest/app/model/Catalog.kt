package com.mindquest.app.model

import androidx.annotation.DrawableRes
import com.mindquest.app.R
import com.mindquest.app.data.QuestEntity
import java.time.LocalDate
import java.time.temporal.WeekFields


data class Meditation(
    val id: String,
    val title: String,
    val category: String,
    val description: String,
    val minutes: Int,
    val guide: String,
    val experience: String,
    @DrawableRes val image: Int,
    val sound: Int,
    val xp: Int = 100,
    val gold: Int = 40,
    val sleep: Boolean = false
)

object Catalog {
    val meditations = listOf(
        Meditation("calm", "A Calm Beginning", "Daily", "Slow down, notice your breathing, and arrive in the present.", 5,
            "Welcome to a calm beginning. Find a comfortable position. Let your shoulders soften. Breathe at an easy, natural pace. If a thought arises, notice it gently. There is nothing to achieve. Return your attention to the next breath. Allow the sounds of the night garden to accompany a peaceful pause.", "Beginner", R.drawable.scene_lake, R.raw.moonlit_ambient),
        Meditation("forest", "Whispering Forest", "Stress Relief", "A gentle pause inspired by a peaceful woodland walk.", 7,
            "Imagine standing in a quiet forest. Listen to the leaves in the breeze. Notice where your body touches the ground or chair. You can let each breath come and go without forcing it. For the next few minutes, give yourself permission simply to rest.", "All levels", R.drawable.scene_forest, R.raw.gentle_rain),
        Meditation("focus", "Clear the Mind", "Focus", "Return attention to one simple anchor, one breath at a time.", 10,
            "Choose a natural point of focus: your breathing, a sound, or the feeling of your feet. Whenever attention wanders, acknowledge the distraction and return. This is practice, not a test.", "All levels", R.drawable.scene_observatory, R.raw.stardust_chimes),
        Meditation("gratitude", "Three Small Lights", "Gratitude", "Appreciate a few ordinary moments without pressure.", 5,
            "Recall a small moment that felt pleasant or meaningful today. It may be a sound, a kindness, or a warm drink. Notice it, then let it pass. If gratitude feels difficult, that is okay too. Rest with what is present.", "Beginner", R.drawable.scene_meadow, R.raw.moonlit_ambient),
        Meditation("body", "Gentle Body Scan", "Mindfulness", "Check in with sensations from head to toe.", 8,
            "Notice your forehead and jaw, then your shoulders, hands, and feet. There is no need to change any sensation. If a part of the body feels uncomfortable, you can move attention elsewhere. Continue gently.", "Beginner", R.drawable.scene_garden, R.raw.gentle_rain),
        Meditation("sleep", "Moonlit Rest", "Sleep", "A quiet bedtime session with soft atmospheric sounds.", 12,
            "The day is finished. You do not need to solve tomorrow tonight. Listen to the hush of the lake. Let thoughts pass through as clouds pass across the stars. Settle into a comfortable resting position.", "All levels", R.drawable.scene_village, R.raw.moonlit_ambient, sleep=true),
        Meditation("rain", "Rain on the Cottage", "Sleep", "Unwind with a soft rain soundscape.", 15,
            "Listen to the gentle rainfall around a quiet cottage. Allow your breathing to be easy and unhurried. Feel free to close your eyes and rest.", "All levels", R.drawable.scene_castle, R.raw.gentle_rain, sleep=true),
        Meditation("stardust", "Stardust Sky", "Relaxation", "Soft chimes and a spacious evening sky.", 6,
            "Imagine a wide night sky filled with gentle points of light. Notice the space around each sound. Breathe naturally and return to the present whenever you wish.", "Beginner", R.drawable.scene_sky, R.raw.stardust_chimes),
        Meditation("study", "Study Reset", "Focus", "A mindful break before returning to a learning task.", 4,
            "Place both feet comfortably. Relax your hands. Let one breath begin and end. Choose just one small task to return to when this break concludes. There is no need to rush.", "Beginner", R.drawable.scene_observatory, R.raw.moonlit_ambient),
        Meditation("story_cottage", "The Lantern Keeper", "Sleep Stories", "An original tale of a gentle lantern keeper and a starry village.", 12,
            "In a small village beyond the lavender hills, there lived a lantern keeper named Elio. Each evening, Elio walked along a quiet lane, lighting one warm lantern after another. The light did not need to be bright. It only needed to tell each traveler that home was nearby. On one peaceful evening, a silver moth followed him across the bridge. The moth paused at each lantern as though checking that every light was comfortable. Elio passed the baker's cottage, where the last loaf rested on a wooden shelf. He passed the library, where all the books slept between their covers. Finally, he reached the lake. There, the moon stretched a soft path over the water. Elio sat on a bench and listened to the reeds moving gently. He did not count the stars. He did not plan his morning. He watched the silver moth settle on a lavender flower. And when it was time to return, he carried the quiet feeling with him all the way home. The village rested under its thousand gentle lights, and the night was peaceful.",
            "All levels",R.drawable.scene_village,R.raw.moonlit_ambient,sleep=true),
        Meditation("story_river", "Letters from Crystal Lake", "Sleep Stories", "An original gentle fantasy story beside a moonlit lake.", 15,
            "There was once a lake that gathered small reflections. Not wishes that needed to come true, and not memories that needed to be kept, but ordinary little moments of light. Each evening, the lake welcomed the colors of the sky. Blue arrived first, then lavender, then a handful of silver stars. On a wooden dock, a traveler named Nima sat with a blank notebook. Nima had planned to write an important letter but found no words. So Nima simply listened. A breeze moved the water. Somewhere far away, a door closed softly. A leaf touched the surface of the lake and floated past. Nima wrote, Today I noticed a leaf. That seemed enough. The next line said, I heard the quiet water. And the last line said, Tonight I can rest. Nima closed the notebook and returned to the cottage. The little reflections remained in the lake, freely drifting under the moon. There was nothing else to do, and nowhere else to be.",
            "All levels",R.drawable.scene_lake,R.raw.stardust_chimes,sleep=true),
        Meditation("silent", "Quiet Timer", "Timer", "Unguided five-minute meditation with optional original ambience.", 5,
            "", "All levels",R.drawable.scene_garden,R.raw.moonlit_ambient,xp=75,gold=30)
    )
    val categories = listOf("All", "Daily", "Stress Relief", "Focus", "Mindfulness", "Relaxation", "Gratitude", "Sleep", "Sleep Stories", "Timer")
    val questSeeds = listOf(
        QuestEntity(title="Meditate for 5 minutes", detail="Enjoy a little quiet time", category="Mindfulness", minutes=5, xp=100, gold=50),
        QuestEntity(title="Read for 20 minutes", detail="Read something interesting", category="Learning", minutes=20, xp=80, gold=40),
        QuestEntity(title="Practice gratitude", detail="Write one small thing you appreciate", category="Wellness", minutes=3, xp=80, gold=40),
        QuestEntity(title="Study session", detail="A focused block of learning", category="Learning", minutes=25, xp=120, gold=60),
        QuestEntity(title="Organize my space", detail="Make one corner a little calmer", category="Personal", minutes=10, xp=60, gold=30)
    )
}

data class ShopItem(
    val id: String,
    val name: String,
    val rarity: String,
    val price: Int,
    val description: String,
    @DrawableRes val image: Int
)
object Shop {
    val items = listOf(
        ShopItem("cloak", "Traveler's Cloak", "Rare", 120, "A cozy cloak for wandering the world.", R.drawable.item_cloak),
        ShopItem("crystal", "Azure Crystal", "Uncommon", 70, "A luminous keepsake from Crystal Lake.", R.drawable.item_crystal),
        ShopItem("cat", "Moon Cat", "Epic", 250, "An adorable cosmetic companion.", R.drawable.item_cat),
        ShopItem("potion", "Rose Potion", "Common", 35, "A decorative bottle; no real-world effect.", R.drawable.item_potion),
        ShopItem("key", "Old Golden Key", "Rare", 150, "A collectible golden key.", R.drawable.item_key),
        ShopItem("lantern", "Forest Lantern", "Uncommon", 85, "A glow for quiet adventures.", R.drawable.item_lantern),
        ShopItem("blossom", "Lavender Blossom", "Common", 35, "A small flower from the garden.", R.drawable.item_blossom),
        ShopItem("moon", "Crescent Charm", "Rare", 145, "A symbol of peaceful nights.", R.drawable.item_moon),
        ShopItem("staff", "Stardust Staff", "Epic", 300, "A ceremonial decorative staff.", R.drawable.item_staff),
        ShopItem("crown", "Dream Crown", "Legendary", 600, "A golden crown for a star traveler.", R.drawable.item_crown),
        ShopItem("scroll", "Wisdom Scroll", "Common", 50, "A memory of new discoveries.", R.drawable.item_scroll),
        ShopItem("cloud", "Sky Keepsake", "Uncommon", 90, "A tiny cloud collectible.", R.drawable.item_cloud)
    )
}

data class WorldPlace(val name:String, val requiredLevel:Int, val image:Int, val text:String)
val WorldPlaces = listOf(
    WorldPlace("Moonlight Village",1,R.drawable.scene_village,"Your peaceful starting village"),
    WorldPlace("Whispering Forest",2,R.drawable.scene_forest,"Follow fireflies under old trees"),
    WorldPlace("Crystal Lake",3,R.drawable.scene_lake,"Rest beside the sparkling water"),
    WorldPlace("Lavender Meadows",4,R.drawable.scene_meadow,"Wander through a pastel meadow"),
    WorldPlace("Stardust Observatory",5,R.drawable.scene_observatory,"Watch constellations over the hills"),
    WorldPlace("Dream Castle",7,R.drawable.scene_castle,"Discover the misty hilltop castle"),
    WorldPlace("Floating Sky Islands",9,R.drawable.scene_sky,"Drift among the cotton-cloud islands"),
    WorldPlace("Celestial Garden",11,R.drawable.scene_garden,"Visit the hidden starlight sanctuary")
)
fun levelForXp(total: Int): Int = 1 + (total.coerceAtLeast(0) / 250)
fun levelProgress(total: Int): Float = (total.coerceAtLeast(0) % 250) / 250f
fun completionKey(quest: QuestEntity, date: LocalDate = LocalDate.now()): String = when (quest.repeat) {
    "Weekly" -> "W-${date.get(WeekFields.ISO.weekBasedYear())}-${date.get(WeekFields.ISO.weekOfWeekBasedYear())}"
    "Once" -> "FOREVER"
    else -> date.toString()
}
fun questIsDone(quest:QuestEntity) = quest.completedKey == completionKey(quest)
