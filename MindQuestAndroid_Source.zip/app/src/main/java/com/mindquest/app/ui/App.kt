package com.mindquest.app.ui

import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mindquest.app.MainViewModel
import com.mindquest.app.R
import com.mindquest.app.data.HeroEntity
import com.mindquest.app.model.*
import kotlinx.coroutines.launch

val avatars=listOf(R.drawable.avatar_0,R.drawable.avatar_1,R.drawable.avatar_2,
    R.drawable.avatar_3,R.drawable.avatar_4,R.drawable.avatar_5)

@Composable fun MindQuestApp(vm:MainViewModel) {
    val hero by vm.hero.collectAsStateWithLifecycle()
    val quests by vm.quests.collectAsStateWithLifecycle()
    val favorites by vm.favorites.collectAsStateWithLifecycle()
    val inventory by vm.inventory.collectAsStateWithLifecycle()
    val journals by vm.journals.collectAsStateWithLifecycle()
    val logs by vm.logs.collectAsStateWithLifecycle()
    val loadedSettings by vm.settings.collectAsStateWithLifecycle()
    val settings=loadedSettings
    val active by vm.active.collectAsStateWithLifecycle()
    val playerVisible by vm.fullPlayer.collectAsStateWithLifecycle()
    val isPlaying by vm.isPlaying.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableStateOf("Home") }
    var extra by rememberSaveable { mutableStateOf("") }
    var meditationCategory by rememberSaveable { mutableStateOf("All") }
    val snack=remember { SnackbarHostState() }
    val scope=rememberCoroutineScope()
    val ctx=LocalContext.current
    val notificationLauncher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { accepted ->
        if(accepted) vm.reminders(true) else scope.launch { snack.showSnackbar("Notification permission not granted") }
    }
    LaunchedEffect(vm) { vm.events.collect { snack.showSnackbar(it) } }

    if(settings==null) {
        Box(Modifier.fillMaxSize().background(Navy),contentAlignment=Alignment.Center) {
            CircularProgressIndicator(color=Lavender)
        }
        return
    }
    if(!settings.onboardingDone || hero==null) {
        OnboardingScreen(
            onDone={name,avatar,goals,experience,duration,world ->
                vm.setHero(name,avatar);vm.onboardingDone(goals,experience,duration,world)
            },
            onSkip={vm.onboardingDone()}
        )
        return
    }
    val h=hero ?: HeroEntity()
    val immersive=playerVisible && active!=null || extra=="Breathing"
    BackHandler(enabled=immersive || extra.isNotEmpty() || tab!="Home") {
        when {
            playerVisible -> vm.showPlayer(false)
            extra.isNotEmpty() -> extra=""
            tab!="Home" -> tab="Home"
        }
    }
    Scaffold(
        snackbarHost={SnackbarHost(snack)},
        containerColor=Navy,
        bottomBar={
            if(!immersive) Column {
                if(active!=null && !playerVisible) MiniPlayer(active!!,isPlaying,
                    onOpen={vm.showPlayer(true)},onToggle={vm.pauseOrResume()},onStop={vm.stopMeditation()})
                BottomNav(selected=tab,onSelect={tab=it;extra=""})
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).background(
            Brush.verticalGradient(listOf(Navy,Cosmic,Navy)))) {
            when {
                playerVisible && active!=null -> MeditationPlayer(active!!,isPlaying,
                    onBack={vm.showPlayer(false)},onPause={vm.pauseOrResume()},
                    onStop={vm.stopMeditation()},onVoice={vm.toggleVoice()},
                    onSeekAmbient={vm.seekAmbient(it)},onFinish={vm.stopMeditation()})
                extra=="Breathing" -> BreathingScreen(onBack={extra=""},onReward=vm::completeBreathing,
                    reducedMotion=settings.reducedMotion)
                extra=="Journal" -> JournalScreen(journals,onSave=vm::saveJournal,onDelete=vm::deleteJournal,
                    onBack={extra=""})
                extra=="Inventory" -> InventoryScreen(h,inventory,onPurchase=vm::purchase,onEquip=vm::equip,
                    onBack={extra=""})
                extra=="Settings" -> SettingsScreen(settings,
                    onMotion=vm::reduceMotion,onStreak=vm::showStreak,
                    onSound=vm::sleepSound,
                    onReminders={v->
                        if(v && Build.VERSION.SDK_INT>=33 &&
                            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        else vm.reminders(v)
                    },onReset=vm::resetData,onBack={extra=""})
                extra=="Achievements" -> AchievementScreen(h,onBack={extra=""})
                extra=="World" -> WorldScreen(h,onBack={extra=""})
                else -> when(tab) {
                    "Home" -> HomeScreen(h,quests,logs,
                        onQuest={vm.completeQuest(it)},onUndo={vm.undoQuest(it)},
                        onMeditate={vm.beginMeditation(Catalog.meditations.first())},
                        onBreathing={extra="Breathing"},onJournal={extra="Journal"},
                        onSleep={meditationCategory="Sleep";tab="Meditate"},onQuests={tab="Quests"},
                        onAdventure={tab="Adventure"})
                    "Quests" -> QuestScreen(quests,onComplete=vm::completeQuest,onUndo=vm::undoQuest,
                        onSave=vm::saveQuest,onDelete=vm::deleteQuest)
                    "Meditate" -> MeditationScreen(favorites.map{it.contentId}.toSet(),
                        selectedCategory=meditationCategory,onCategoryChange={meditationCategory=it},
                        onFavorite=vm::favorite,onStart=vm::beginMeditation,onBreathing={extra="Breathing"})
                    "Adventure" -> AdventureScreen(h,inventory,
                        onWorld={extra="World"},onInventory={extra="Inventory"},onAchievements={extra="Achievements"})
                    else -> ProfileScreen(h,logs,settings,
                        onJournal={extra="Journal"},onInventory={extra="Inventory"},
                        onSettings={extra="Settings"},onAchievements={extra="Achievements"},
                        onChangeHero=vm::setHero)
                }
            }
        }
    }
}

@Composable private fun BottomNav(selected:String,onSelect:(String)->Unit) {
    val tabs=listOf(
        Triple("Home",R.drawable.nav_home,"Home"),
        Triple("Quests",R.drawable.nav_quests,"Quests"),
        Triple("Meditate",R.drawable.nav_meditate,"Meditate"),
        Triple("Adventure",R.drawable.nav_adventure,"Adventure"),
        Triple("Profile",R.drawable.nav_profile,"Profile")
    )
    Row(Modifier.fillMaxWidth().background(Panel).border(1.dp,PanelEdge)
        .navigationBarsPadding().padding(vertical=5.dp,horizontal=3.dp),
        horizontalArrangement=Arrangement.SpaceEvenly) {
        tabs.forEach { (title,ico,desc) ->
            val chosen=selected==title
            Column(Modifier.weight(1f).height(55.dp)
                .border(1.dp,if(chosen)Lavender else ColorUnspecified(),PixelShape)
                .background(if(chosen)Indigo else Panel,PixelShape)
                .clickable { onSelect(title) }.padding(4.dp),
                horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
                Image(painterResource(ico),desc,Modifier.size(25.dp))
                Text(title,fontSize=9.sp,fontWeight=if(chosen)FontWeight.Bold else FontWeight.Normal,
                    color=if(chosen)Cream else Muted,maxLines=1)
            }
        }
    }
}
private fun ColorUnspecified()=Panel

@Composable private fun MiniPlayer(
    session:com.mindquest.app.ActiveMeditation, playing:Boolean,
    onOpen:()->Unit,onToggle:()->Unit,onStop:()->Unit
) {
    Row(Modifier.fillMaxWidth().background(Indigo).border(1.dp,PanelEdge)
        .clickable { onOpen() }.padding(horizontal=9.dp,vertical=6.dp),
        verticalAlignment=Alignment.CenterVertically,
        horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        Image(painterResource(session.content.image),null,Modifier.size(39.dp),contentScale=ContentScale.Crop)
        Column(Modifier.weight(1f)) {
            Text(session.content.title,color=Cream,fontWeight=FontWeight.Bold,fontSize=13.sp)
            Text(if(session.complete)"Complete!" else "${session.elapsedMs/1000}s / ${session.content.minutes*60}s",
                color=Muted,fontSize=10.sp)
        }
        IconButton(onClick=onToggle) { Icon(if(playing)Icons.Filled.Pause else Icons.Filled.PlayArrow,"Play or pause",tint=Green) }
        IconButton(onClick=onStop) { Icon(Icons.Filled.Close,"Stop",tint=Muted) }
    }
}

@Composable private fun OnboardingScreen(
    onDone:(String,Int,List<String>,String,Int,String)->Unit,
    onSkip:()->Unit
) {
    var step by rememberSaveable{mutableIntStateOf(0)}
    var name by rememberSaveable { mutableStateOf("Traveler") }
    var avatar by rememberSaveable { mutableIntStateOf(0) }
    var experience by rememberSaveable { mutableStateOf("New to meditation") }
    var duration by rememberSaveable { mutableIntStateOf(5) }
    var world by rememberSaveable { mutableStateOf("Moonlight Village") }
    val goals=remember { mutableStateListOf("Feel calmer") }
    val allGoals=listOf("Feel calmer","Sleep peacefully","Build habits","Study with focus","Practice gratitude")
    Column(Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState())
        .statusBarsPadding().navigationBarsPadding().padding(16.dp),
        verticalArrangement=Arrangement.spacedBy(14.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Image(painterResource(R.drawable.splash_scene),null,Modifier.fillMaxWidth().height(215.dp),contentScale=ContentScale.Crop)
        PixelTitle("✦ MINDQUEST ✦",color=Gold,size=25.sp)
        Text("Meditation · Habits · Adventure",color=Muted,fontSize=12.sp)
        PixelPanel(Modifier.fillMaxWidth()) {
            Text("CHAPTER ${step+1} OF 5",color=Cyan,fontSize=11.sp)
            when(step) {
                0 -> {
                    PixelTitle("Welcome, Traveler!",size=19.sp)
                    Text("A peaceful little world awaits. Rest, complete real-life quests and unlock charming places — all at your own pace.")
                    Text("Everything starts locally on your Android device. No account needed.",color=Muted,fontSize=12.sp)
                }
                1 -> {
                    PixelTitle("Create Your Hero",size=18.sp)
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center) {
                        Image(painterResource(avatars[avatar]),"Selected character",Modifier.size(100.dp))
                    }
                    OutlinedTextField(name,{name=it.take(24)},label={Text("Character name")},singleLine=true,modifier=Modifier.fillMaxWidth())
                    Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                        avatars.forEachIndexed { idx,id ->
                            Image(painterResource(id),"Character ${idx+1}",Modifier.size(54.dp)
                                .border(if(avatar==idx)3.dp else 1.dp,if(avatar==idx)Green else PanelEdge,PixelShape)
                                .clickable{avatar=idx})
                        }
                    }
                }
                2 -> {
                    PixelTitle("Your Goals",size=18.sp)
                    Text("Choose what matters to you. Change direction anytime.",color=Muted)
                    allGoals.forEach { goal ->
                        Row(Modifier.fillMaxWidth().clickable {
                            if(goal in goals)goals.remove(goal) else goals.add(goal)
                        },verticalAlignment=Alignment.CenterVertically) {
                            Checkbox(goal in goals,onCheckedChange={if(it)goals.add(goal) else goals.remove(goal)})
                            Text(goal)
                        }
                    }
                }
                3 -> {
                    PixelTitle("Your Pace",size=18.sp)
                    Text("Meditation experience",color=Muted)
                    listOf("New to meditation","Some experience","Regular practice").forEach {
                        Row(Modifier.fillMaxWidth().clickable{experience=it},verticalAlignment=Alignment.CenterVertically) {
                            RadioButton(experience==it,onClick={experience=it});Text(it)
                        }
                    }
                    Text("Preferred session duration",color=Muted)
                    Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                        listOf(3,5,10,15).forEach { m ->
                            FilterChip(selected=duration==m,onClick={duration=m},label={Text("$m min")})
                        }
                    }
                }
                else -> {
                    PixelTitle("Your Starting Place",size=18.sp)
                    Text("Every explorer deserves a cozy first home.",color=Muted)
                    listOf("Moonlight Village","Whispering Forest","Crystal Lake").forEach { loc ->
                        Row(Modifier.fillMaxWidth().clickable{world=loc},verticalAlignment=Alignment.CenterVertically) {
                            RadioButton(world==loc,onClick={world=loc});Text(loc)
                        }
                    }
                    Text("You are free to explore without streak pressure or mandatory check-ins.",color=Muted,fontSize=12.sp)
                }
            }
        }
        PixelButton(if(step==4)"BEGIN ADVENTURE" else "CONTINUE",{
            if(step<4)step++ else onDone(name,avatar,goals.toList(),experience,duration,world)
        },Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            TextButton(onClick={if(step>0)step-- else onSkip()}) { Text(if(step>0)"Back" else "Skip setup") }
            if(step in 1..3) TextButton(onClick={step++}) { Text("Skip question") }
        }
    }
}
