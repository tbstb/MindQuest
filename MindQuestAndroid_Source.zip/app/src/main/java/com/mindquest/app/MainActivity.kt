package com.mindquest.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mindquest.app.ui.MindQuestApp
import com.mindquest.app.ui.MindQuestTheme

class MainActivity:ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MindQuestTheme {
                val vm:MainViewModel=viewModel()
                MindQuestApp(vm)
            }
        }
    }
}
