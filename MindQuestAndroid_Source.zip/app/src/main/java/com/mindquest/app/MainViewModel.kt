package com.mindquest.app

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mindquest.app.audio.AudioBridge
import com.mindquest.app.audio.GuideVoice
import com.mindquest.app.data.*
import com.mindquest.app.model.Meditation
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.UUID


data class ActiveMeditation(
    val content: Meditation,
    val token: String,
    val elapsedMs: Long=0,
    val complete: Boolean=false
)

class MainViewModel(app:Application):AndroidViewModel(app) {
    val repository=MindRepository(app)
    val audio=AudioBridge(app)
    private val voice=GuideVoice(app)
    val hero=repository.hero.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),null)
    val quests=repository.quests.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val inventory=repository.inventory.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val journals=repository.journal.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val logs=repository.activityLogs.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val favorites=repository.favorites.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val settings:StateFlow<UserSettings?> = repository.preferences.stateIn(
        viewModelScope,SharingStarted.WhileSubscribed(5000),null)
    val isPlaying=audio.playing
    private val _active=MutableStateFlow<ActiveMeditation?>(null)
    val active:StateFlow<ActiveMeditation?> = _active
    private val _fullPlayer=MutableStateFlow(false)
    val fullPlayer:StateFlow<Boolean> = _fullPlayer
    private val _events=MutableSharedFlow<String>(extraBufferCapacity=10)
    val events=_events.asSharedFlow()
    private var lastTick=SystemClock.elapsedRealtime()
    private var guideOn=true
    init {
        viewModelScope.launch { repository.seedIfNecessary() }
        viewModelScope.launch {
            while(isActive) {
                delay(if(_active.value==null) 1000L else 400L)
                val now=SystemClock.elapsedRealtime()
                val elapsed=(now-lastTick).coerceIn(0,2500)
                lastTick=now
                val running=_active.value
                if(running!=null && !running.complete && audio.playing.value) {
                    val newElapsed=running.elapsedMs+elapsed
                    val maximum=running.content.minutes*60_000L
                    if(running.content.sleep) {
                        val muted=settings.value?.sleepSoundsEnabled==false
                        audio.setVolume(if(muted) 0f else ((maximum-newElapsed)/20_000f).coerceIn(0f,1f))
                    }
                    if(newElapsed>=maximum) finishCurrent(running.copy(elapsedMs=maximum))
                    else _active.value=running.copy(elapsedMs=newElapsed)
                }
            }
        }
    }
    private fun action(block:suspend ()->Unit) {
        viewModelScope.launch {
            try { block() } catch(e:Exception) {
                _events.emit(e.localizedMessage ?: "Action could not be completed")
            }
        }
    }
    private fun announce(s:String) { _events.tryEmit(s) }
    fun setHero(name:String,avatar:Int) = action { repository.setIdentity(name,avatar) }
    fun onboardingDone(goals:List<String> = emptyList(),experience:String = "New to meditation",
                       duration:Int=5,world:String="Moonlight Village") = action {
        repository.finishOnboarding(goals,experience,duration,world)
    }
    fun completeQuest(id:Long)=action { announce(repository.markQuest(id)) }
    fun undoQuest(id:Long)=action { announce(repository.undoQuest(id)) }
    fun saveQuest(q:QuestEntity)=action { repository.saveQuest(q);announce("Quest saved") }
    fun deleteQuest(id:Long)=action { repository.removeQuest(id);announce("Quest deleted") }
    fun favorite(id:String)=action { repository.toggleFavorite(id) }
    fun purchase(id:String)=action { announce(repository.purchase(id)) }
    fun equip(id:String)=action { announce(repository.equip(id)) }
    fun saveJournal(mood:String,note:String)=action { repository.addJournal(mood,note);announce("Reflection saved privately on this device") }
    fun deleteJournal(id:Long)=action { repository.deleteJournal(id);announce("Entry deleted") }
    fun reduceMotion(v:Boolean)=action { repository.settings.setReducedMotion(v) }
    fun showStreak(v:Boolean)=action { repository.settings.setStreak(v) }
    fun reminders(v:Boolean)=action { repository.updateReminders(v) }
    fun sleepSound(v:Boolean)=action { repository.settings.setSleepSound(v) }
    fun resetData()=action { stopMeditation();repository.resetLocalData();announce("Local progress reset") }

    fun beginMeditation(content:Meditation) {
        audio.stop(); voice.stop()
        _active.value=ActiveMeditation(content,UUID.randomUUID().toString())
        _fullPlayer.value=true
        lastTick=SystemClock.elapsedRealtime()
        audio.setVolume(if(content.sleep && settings.value?.sleepSoundsEnabled==false)0f else 1f)
        audio.play(content.sound,content.title)
        if(guideOn) voice.speak(content.guide)
    }
    fun toggleVoice():Boolean {
        guideOn=!guideOn
        if(guideOn) _active.value?.let{voice.speak(it.content.guide)} else voice.stop()
        announce(if(guideOn) "Voice guidance on" else "Voice guidance off")
        return guideOn
    }
    fun showPlayer(show:Boolean) { _fullPlayer.value=show }
    fun pauseOrResume() { if(audio.playing.value) { audio.pause();voice.stop() } else {
        audio.resume();if(guideOn) _active.value?.let { voice.speak("Welcome back. Continue breathing naturally.") }
    }}
    fun seekAmbient(fraction:Float) = audio.seekAmbient(fraction)
    fun stopMeditation() { voice.stop();audio.stop();_active.value=null;_fullPlayer.value=false }
    private fun finishCurrent(session:ActiveMeditation) {
        if(session.complete) return
        _active.value=session.copy(complete=true)
        audio.pause();voice.stop()
        action {
            val c=session.content
            val saved=repository.completeActivity(session.token,c.id,"meditation",c.minutes,c.xp,c.gold)
            if(saved) announce("QUEST COMPLETE · +${c.xp} XP · +${c.gold} gold")
        }
    }
    fun completeBreathing(token:String, minutes:Int) = action {
        val saved=repository.completeActivity(token,"breathing","breathing",minutes,55,25)
        if(saved) announce("Breathing complete · +55 XP · +25 gold")
    }
    override fun onCleared() { voice.close();audio.release();super.onCleared() }
}
