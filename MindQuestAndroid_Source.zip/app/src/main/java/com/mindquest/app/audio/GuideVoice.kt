package com.mindquest.app.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Uses the user's installed Android TTS voice; supplied guide scripts are original. */
class GuideVoice(context:Context) {
    private var engine:TextToSpeech?=null
    private var ready=false
    private var pending:String?=null
    init {
        engine=TextToSpeech(context.applicationContext) { state ->
            ready=state==TextToSpeech.SUCCESS
            if(ready) {
                engine?.setLanguage(Locale.US)
                engine?.setPitch(.96f)
                engine?.setSpeechRate(.83f)
                pending?.let { speak(it) }
            }
        }
    }
    fun speak(text:String) {
        if(!ready) { pending=text;return }
        pending=null
        engine?.speak(text,TextToSpeech.QUEUE_FLUSH,null,"mindquest-voice")
    }
    fun stop() { pending=null;engine?.stop() }
    fun close() { engine?.shutdown();engine=null }
}
