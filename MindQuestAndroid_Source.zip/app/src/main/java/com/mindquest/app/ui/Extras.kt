package com.mindquest.app.ui

import android.content.Intent
import android.os.SystemClock
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.mindquest.app.R
import com.mindquest.app.data.*
import com.mindquest.app.model.*
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID

@Composable fun ReturnHeader(title:String,onBack:()->Unit) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
        IconButton(onClick=onBack){Icon(Icons.Filled.ArrowBack,"Back",tint=Cream)}
        PixelTitle(title,size=18.sp)
    }
}

@Composable fun AdventureScreen(hero:HeroEntity,inventory:List<InventoryEntity>,
                                onWorld:()->Unit,onInventory:()->Unit,onAchievements:()->Unit) {
    val level=levelForXp(hero.xp)
    val unlocked=WorldPlaces.count { it.requiredLevel<=level }
    PageColumn {
        SectionHeading("ADVENTURE WORLD","Explore at your own gentle pace")
        SceneBanner(R.drawable.scene_castle,"THE DREAMLANDS","$unlocked / ${WorldPlaces.size} locations unlocked",height=205.dp)
        HeroHeader(hero)
        PixelPanel(Modifier.fillMaxWidth()) {
            PixelTitle("WORLD EXPLORATION",size=15.sp)
            XpMeter(unlocked.toFloat()/WorldPlaces.size)
            Text("Discover beautiful new locations as you earn XP. All unlocked places stay available.",fontSize=12.sp,color=Muted)
            PixelButton("OPEN WORLD MAP",onWorld,Modifier.fillMaxWidth())
        }
        Row(horizontalArrangement=Arrangement.spacedBy(9.dp)) {
            Column(Modifier.weight(1f).border(1.dp,PanelEdge,PixelShape).background(Panel,PixelShape)
                .clickable(onClick=onInventory).padding(12.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                Icon(Icons.Filled.Inventory2,"Inventory",tint=Gold,modifier=Modifier.size(35.dp))
                Text("INVENTORY",fontSize=12.sp,color=Cream,fontWeight=FontWeight.Bold)
                Text("${inventory.sumOf { it.quantity }} items",fontSize=11.sp,color=Muted)
            }
            Column(Modifier.weight(1f).border(1.dp,PanelEdge,PixelShape).background(Panel,PixelShape)
                .clickable(onClick=onAchievements).padding(12.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                Icon(Icons.Filled.EmojiEvents,"Achievements",tint=Gold,modifier=Modifier.size(35.dp))
                Text("ACHIEVEMENTS",fontSize=12.sp,color=Cream,fontWeight=FontWeight.Bold)
                Text("Your milestones",fontSize=11.sp,color=Muted)
            }
        }
        SectionHeading("NEXT DESTINATION")
        val next=WorldPlaces.firstOrNull { it.requiredLevel>level }
        if(next!=null) {
            SceneBanner(next.image,next.name,"Unlocks at level ${next.requiredLevel}",height=142.dp)
        } else Text("All locations unlocked! Enjoy wandering freely.",color=Green)
    }
}

@Composable fun WorldScreen(hero:HeroEntity,onBack:()->Unit) {
    val level=levelForXp(hero.xp)
    var selected by remember { mutableStateOf<WorldPlace?>(null) }
    PageColumn {
        ReturnHeader("FANTASY WORLD",onBack)
        Text("Travel between your unlocked locations. Scenes are offline and free to revisit.",color=Muted,fontSize=12.sp)
        WorldPlaces.forEach { place ->
            val open=level>=place.requiredLevel
            Column(Modifier.fillMaxWidth().border(2.dp,if(open)Lavender else PanelEdge,PixelShape)
                .clickable(enabled=open){selected=place}) {
                Box {
                    Image(painterResource(place.image),place.name,
                        Modifier.fillMaxWidth().height(138.dp),contentScale=ContentScale.Crop,
                        alpha=if(open)1f else .42f)
                    if(!open) Icon(Icons.Filled.Lock,"Locked",Modifier.align(Alignment.Center)
                        .size(32.dp),tint=Gold)
                }
                Row(Modifier.fillMaxWidth().background(Panel).padding(9.dp),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        PixelTitle(place.name,size=13.sp)
                        Text(place.text,color=Muted,fontSize=11.sp)
                    }
                    Tag(if(open)"EXPLORE" else "LV ${place.requiredLevel}",if(open)Green else Gold)
                }
            }
        }
    }
    selected?.let { place ->
        AlertDialog(onDismissRequest={selected=null},containerColor=Panel,
            title={PixelTitle(place.name,size=16.sp)},
            text={Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Image(painterResource(place.image),null,Modifier.fillMaxWidth().height(170.dp),contentScale=ContentScale.Crop)
                Text(place.text,color=Cream)
                Text("A peaceful destination to enjoy. No timer or challenge is required.",color=Muted,fontSize=12.sp)
            }},confirmButton={TextButton(onClick={selected=null}){Text("Close",color=Green)}})
    }
}

@Composable fun InventoryScreen(hero:HeroEntity,inventory:List<InventoryEntity>,
                                onPurchase:(String)->Unit,onEquip:(String)->Unit,onBack:()->Unit) {
    var shop by remember { mutableStateOf(false) }
    val owned=inventory.associateBy { it.itemId }
    val goods=if(shop)Shop.items else Shop.items.filter { it.id in owned }
    Column(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        ReturnHeader("${if(shop)"GOLDEN SHOP" else "INVENTORY"}",onBack)
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text("🟡 ${hero.gold} gold",color=Gold,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
            FilterChip(shop,onClick={shop=true},label={Text("Shop")})
            Spacer(Modifier.width(8.dp))
            FilterChip(!shop,onClick={shop=false},label={Text("Owned")})
        }
        Text(if(shop)"Cosmetic items only — no real-money purchases."
             else "Equip one of your collectible items.",color=Muted,fontSize=12.sp)
        if(goods.isEmpty()) Text("Your bag is empty. Visit the shop to collect something cozy.",color=Muted)
        LazyVerticalGrid(columns=GridCells.Fixed(2),modifier=Modifier.weight(1f),
            horizontalArrangement=Arrangement.spacedBy(9.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
            items(goods,key={it.id}) { item ->
                val own=owned[item.id]
                Column(Modifier.fillMaxWidth().border(2.dp,PanelEdge,PixelShape).background(Panel,PixelShape)
                    .padding(9.dp),horizontalAlignment=Alignment.CenterHorizontally,
                    verticalArrangement=Arrangement.spacedBy(5.dp)) {
                    Image(painterResource(item.image),item.name,Modifier.size(70.dp))
                    Text(item.name,color=Cream,fontSize=12.sp,fontWeight=FontWeight.Bold,maxLines=1)
                    Tag(item.rarity,when(item.rarity) {
                        "Common"->Muted;"Uncommon"->Green;"Rare"->Cyan;"Epic"->Lavender;else->Gold
                    })
                    Text(item.description,color=Muted,fontSize=10.sp,maxLines=2,
                        textAlign=TextAlign.Center,modifier=Modifier.heightIn(min=30.dp))
                    if(shop) {
                        PixelButton(if(own!=null)"BUY AGAIN · ${item.price}" else "BUY · ${item.price}",
                            {onPurchase(item.id)},Modifier.fillMaxWidth(),enabled=hero.gold>=item.price)
                    } else {
                        Text("Owned: ${own?.quantity ?: 0}",color=Muted,fontSize=10.sp)
                        PixelButton(if(own?.equipped==true)"EQUIPPED" else "EQUIP",
                            {onEquip(item.id)},Modifier.fillMaxWidth(),primary=own?.equipped!=true,
                            enabled=own?.equipped!=true)
                    }
                }
            }
        }
    }
}

private data class BadgeInfo(val name:String,val description:String,val reached:Boolean,val progress:String,val icon:Int)
private fun badges(h:HeroEntity)=listOf(
    BadgeInfo("First Steps","Complete one real-world quest",h.questsCompleted>=1,"${h.questsCompleted}/1",R.drawable.item_key),
    BadgeInfo("Mindful Moment","Finish one meditation",h.meditationsCompleted>=1,"${h.meditationsCompleted}/1",R.drawable.item_moon),
    BadgeInfo("Focus Apprentice","Complete 10 quests",h.questsCompleted>=10,"${h.questsCompleted}/10",R.drawable.item_scroll),
    BadgeInfo("Calm Explorer","Finish 10 meditations",h.meditationsCompleted>=10,"${h.meditationsCompleted}/10",R.drawable.item_crystal),
    BadgeInfo("Forest Explorer","Reach level 2",levelForXp(h.xp)>=2,"LV ${levelForXp(h.xp)}/2",R.drawable.item_blossom),
    BadgeInfo("Moonlight Traveler","Reach level 5",levelForXp(h.xp)>=5,"LV ${levelForXp(h.xp)}/5",R.drawable.item_lantern),
    BadgeInfo("Gentle Breath","Complete one breathing exercise",h.breathingCompleted>=1,"${h.breathingCompleted}/1",R.drawable.item_cloud),
    BadgeInfo("100 Mindful Minutes","Record 100 practice minutes",h.mindfulMinutes>=100,"${h.mindfulMinutes}/100",R.drawable.item_staff),
    BadgeInfo("Golden Collector","Earn 1000 gold in total",h.totalGoldEarned>=1000,"${h.totalGoldEarned}/1000",R.drawable.item_crown)
)

@Composable fun AchievementScreen(hero:HeroEntity,onBack:()->Unit) {
    val all=badges(hero)
    PageColumn {
        ReturnHeader("ACHIEVEMENTS",onBack)
        Text("${all.count {it.reached}} of ${all.size} unlocked",color=Gold)
        all.forEach { a ->
            Row(Modifier.fillMaxWidth().border(1.dp,PanelEdge,PixelShape).background(Panel,PixelShape)
                .padding(10.dp),verticalAlignment=Alignment.CenterVertically,
                horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                Image(painterResource(a.icon),a.name,Modifier.size(57.dp),alpha=if(a.reached)1f else .35f)
                Column(Modifier.weight(1f)) {
                    PixelTitle(a.name,size=13.sp,color=if(a.reached)Gold else Muted)
                    Text(a.description,color=Muted,fontSize=11.sp)
                    Text(a.progress,color=if(a.reached)Green else Cyan,fontSize=11.sp)
                }
                Icon(if(a.reached)Icons.Filled.CheckCircle else Icons.Filled.Lock,
                    null,tint=if(a.reached)Green else Muted)
            }
        }
    }
}

@Composable fun ProfileScreen(hero:HeroEntity,logs:List<ActivityLogEntity>,settings:UserSettings,
                              onJournal:()->Unit,onInventory:()->Unit,onSettings:()->Unit,
                              onAchievements:()->Unit,onChangeHero:(String,Int)->Unit) {
    var editHero by remember { mutableStateOf(false) }
    val achieved=badges(hero).count { it.reached }
    PageColumn {
        SectionHeading("YOUR PROFILE","A record of your own peaceful journey")
        HeroHeader(hero)
        PixelPanel(Modifier.fillMaxWidth()) {
            PixelTitle("YOUR JOURNEY SETTINGS",size=14.sp)
            Text("Goals: ${settings.selectedGoals.replace("|", ", ")}",color=Cream,fontSize=12.sp)
            Text("Experience: ${settings.experienceLevel}",color=Muted,fontSize=11.sp)
            Text("Preferred session: ${settings.preferredMinutes} minutes",color=Muted,fontSize=11.sp)
        }
        PixelButton("CUSTOMIZE HERO",{editHero=true},Modifier.fillMaxWidth(),primary=false)
        PixelPanel(Modifier.fillMaxWidth()) {
            PixelTitle("ADVENTURER STATS",size=15.sp)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) {
                MiniStat(hero.focusPoints.toString(),"FOCUS")
                MiniStat(hero.wisdomPoints.toString(),"WISDOM")
                MiniStat(hero.calmPoints.toString(),"CALM")
            }
            Text("Fantasy attributes earned through quests and practices. Not health measurements.",color=Muted,fontSize=10.sp)
        }
        PixelPanel(Modifier.fillMaxWidth()) {
            PixelTitle("YOUR ACTIVITY",size=15.sp)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) {
                MiniStat("${hero.mindfulMinutes}","MINDFUL MIN")
                MiniStat("${hero.meditationsCompleted}","MEDITATIONS")
                MiniStat("${hero.questsCompleted}","QUESTS")
            }
            val today=LocalDate.now()
            val counts=logs.groupingBy { Instant.ofEpochMilli(it.timestamp)
                .atZone(ZoneId.systemDefault()).toLocalDate() }.eachCount()
            Text("ACTIVITY · LAST 35 DAYS",color=Muted,fontSize=10.sp)
            repeat(5) { week ->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                    repeat(7) { d ->
                        val date=today.minusDays((34-week*7-d).toLong())
                        val count=counts[date] ?: 0
                        Box(Modifier.weight(1f).height(20.dp).border(1.dp,PanelEdge)
                            .background(when {
                                count>=3 -> Green
                                count>=1 -> Green.copy(alpha=.55f)
                                else -> Indigo
                            }))
                    }
                }
            }
            if(settings.streakVisible) {
                val dates=counts.keys
                var cursor=today
                if(cursor !in dates)cursor=cursor.minusDays(1)
                var voluntaryStreak=0
                while(cursor in dates) { voluntaryStreak++;cursor=cursor.minusDays(1) }
                Text("Optional practice streak: $voluntaryStreak days",color=Gold,fontSize=12.sp)
            }
            Text("No streak requirement. Quiet days are okay.",color=Muted,fontSize=11.sp)
        }
        PixelPanel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                PixelTitle("MILESTONES",Modifier.weight(1f),size=15.sp)
                Tag("$achieved UNLOCKED",Gold)
            }
            PixelButton("VIEW ACHIEVEMENTS",onAchievements,Modifier.fillMaxWidth(),primary=false)
        }
        PixelButton("📖 JOURNAL",onJournal,Modifier.fillMaxWidth(),primary=false)
        PixelButton("🎒 INVENTORY",onInventory,Modifier.fillMaxWidth(),primary=false)
        PixelButton("⚙ SETTINGS & PRIVACY",onSettings,Modifier.fillMaxWidth(),primary=false)
    }
    if(editHero) {
        var name by remember { mutableStateOf(hero.name) }
        var selectedAvatar by remember { mutableIntStateOf(hero.avatar) }
        AlertDialog(onDismissRequest={editHero=false},containerColor=Panel,
            title={PixelTitle("EDIT HERO",size=17.sp)},
            text={Column(verticalArrangement=Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(name,{name=it.take(24)},label={Text("Display name")},singleLine=true)
                Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    avatars.forEachIndexed {i,img->
                        Image(painterResource(img),"Avatar $i",Modifier.size(49.dp)
                            .border(if(selectedAvatar==i)2.dp else 1.dp,
                                if(selectedAvatar==i)Green else PanelEdge,PixelShape)
                            .clickable{selectedAvatar=i})
                    }
                }
            }},confirmButton={TextButton(onClick={onChangeHero(name,selectedAvatar);editHero=false}){Text("Save",color=Green)}},
            dismissButton={TextButton(onClick={editHero=false}){Text("Cancel",color=Muted)}})
    }
}

@Composable fun JournalScreen(journals:List<JournalEntity>,onSave:(String,String)->Unit,
                              onDelete:(Long)->Unit,onBack:()->Unit) {
    var mood by remember { mutableStateOf("Calm") }
    var note by remember { mutableStateOf("") }
    val moods=listOf("Calm","Happy","Okay","Worried","Tired")
    val context=LocalContext.current
    PageColumn {
        ReturnHeader("MOOD & JOURNAL",onBack)
        Text("Your reflections are stored locally on this device.",color=Muted,fontSize=12.sp)
        PixelPanel(Modifier.fillMaxWidth()) {
            PixelTitle("HOW ARE YOU FEELING?",size=15.sp)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) {
                moods.forEachIndexed { index,label ->
                    Column(Modifier.border(if(mood==label)2.dp else 1.dp,
                        if(mood==label)Green else PanelEdge,PixelShape)
                        .clickable { mood=label }.padding(4.dp),horizontalAlignment=Alignment.CenterHorizontally) {
                        Image(painterResource(avatars[index]),"$label character",Modifier.size(42.dp))
                        Text(label,color=if(mood==label)Green else Muted,fontSize=10.sp)
                    }
                }
            }
            OutlinedTextField(value=note,onValueChange={note=it.take(6000)},
                label={Text("Today, I'm noticing...")},modifier=Modifier.fillMaxWidth(),minLines=4,maxLines=9)
            PixelButton("SAVE REFLECTION",{onSave(mood,note);note=""},Modifier.fillMaxWidth())
        }
        SectionHeading("PAST REFLECTIONS")
        journals.forEach { entry ->
            PixelPanel(Modifier.fillMaxWidth()) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Tag(entry.mood,Lavender)
                    Spacer(Modifier.weight(1f))
                    Text(Instant.ofEpochMilli(entry.timestamp).atZone(ZoneId.systemDefault())
                        .format(DateTimeFormatter.ofPattern("d MMM yyyy · HH:mm")),color=Muted,fontSize=10.sp)
                }
                Text(entry.note.ifBlank { "Just a quiet check-in." },color=Cream)
                Row {
                    TextButton(onClick={
                        val intent=Intent(Intent.ACTION_SEND).apply {
                            type="text/plain"
                            putExtra(Intent.EXTRA_TEXT,"MindQuest reflection (${entry.mood}):\n${entry.note}")
                        }
                        context.startActivity(Intent.createChooser(intent,"Export reflection"))
                    }) {Icon(Icons.Filled.Share,null,tint=Cyan,modifier=Modifier.size(17.dp));Text(" Share",color=Cyan)}
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick={onDelete(entry.id)}) {Icon(Icons.Filled.Delete,null,tint=Coral,modifier=Modifier.size(17.dp));Text(" Delete",color=Coral)}
                }
            }
        }
        if(journals.isEmpty())Text("Your journal is ready for its first entry.",color=Muted)
    }
}

@Composable fun SettingsScreen(settings:UserSettings,onMotion:(Boolean)->Unit,onStreak:(Boolean)->Unit,
                               onSound:(Boolean)->Unit,onReminders:(Boolean)->Unit,
                               onReset:()->Unit,onBack:()->Unit) {
    var confirmReset by remember { mutableStateOf(false) }
    PageColumn {
        ReturnHeader("SETTINGS",onBack)
        SectionHeading("COMFORT & ACCESSIBILITY")
        SettingToggle("Reduced motion","Minimize animated effects",settings.reducedMotion,onMotion)
        SettingToggle("Show optional streaks","Never penalizes missed days",settings.streakVisible,onStreak)
        SettingToggle("Sleep ambience","Enable immersive sound by default",settings.sleepSoundsEnabled,onSound)
        SectionHeading("GENTLE REMINDERS")
        SettingToggle("Daily reminder","Approximately once each day (Android may delay delivery)",settings.reminders,onReminders)
        Text("Notifications are optional. You can disable them in Android settings as well.",color=Muted,fontSize=11.sp)
        SectionHeading("DATA & PRIVACY")
        PixelPanel(Modifier.fillMaxWidth()) {
            Text("LOCAL-FIRST",color=Green,fontWeight=FontWeight.Bold)
            Text("This version has no cloud account, no analytics SDK, no advertisements, and no subscriptions. Room data is private to the app sandbox and protected by Android's device storage encryption when enabled.",fontSize=12.sp,color=Cream)
            Text("Uninstalling MindQuest deletes locally stored progress and journal content. Backups and cross-device sync are not provided.",fontSize=11.sp,color=Muted)
            PixelButton("RESET ALL LOCAL PROGRESS",{confirmReset=true},Modifier.fillMaxWidth(),primary=false)
        }
        SectionHeading("ABOUT")
        Text("MindQuest 1.0 · Original cozy pixel-art habit and meditation companion.",color=Muted,fontSize=12.sp)
        Text("Not a replacement for professional health or mental health services.",color=Muted,fontSize=11.sp)
    }
    if(confirmReset) AlertDialog(onDismissRequest={confirmReset=false},containerColor=Panel,
        title={PixelTitle("RESET ALL DATA?",size=17.sp)},
        text={Text("This permanently deletes local quests, rewards, inventory, meditations and journal entries. Starter content will be restored.")},
        confirmButton={TextButton(onClick={onReset();confirmReset=false}){Text("Reset",color=Coral)}},
        dismissButton={TextButton(onClick={confirmReset=false}){Text("Cancel")}})
}
@Composable private fun SettingToggle(title:String,description:String,value:Boolean,onValue:(Boolean)->Unit) {
    Row(Modifier.fillMaxWidth().border(1.dp,PanelEdge,PixelShape).background(Panel,PixelShape)
        .padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title,color=Cream,fontWeight=FontWeight.SemiBold)
            Text(description,color=Muted,fontSize=11.sp)
        }
        Switch(value,onCheckedChange=onValue)
    }
}

@Composable fun BreathingScreen(onBack:()->Unit,onReward:(String,Int)->Unit,reducedMotion:Boolean) {
    val phases=mapOf("Relax" to (4 to 6),"Balance" to (4 to 4),"Focus" to (4 to 5),
        "Unwind" to (3 to 6),"Energize" to (3 to 4),"Restore" to (5 to 5))
    var selected by remember { mutableStateOf("Relax") }
    var minutes by remember { mutableIntStateOf(1) }
    var running by remember { mutableStateOf(false) }
    var finished by remember { mutableStateOf(false) }
    var seconds by remember { mutableIntStateOf(0) }
    var token by remember { mutableStateOf(UUID.randomUUID().toString()) }
    val timing=phases.getValue(selected)
    val segment=seconds%(timing.first+timing.second)
    val inhale=segment<timing.first
    val cue=if(inhale)"Breathe in gently" else "Breathe out slowly"
    val targetDp=if(inhale)176.dp else 128.dp
    val orbSize by animateDpAsState(if(reducedMotion)150.dp else targetDp,label="Orb size")
    LaunchedEffect(running) {
        while(running && !finished) {
            delay(1000)
            seconds++
            if(seconds>=minutes*60) {
                running=false;finished=true
                onReward(token,minutes)
            }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(15.dp),
        horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(15.dp)) {
        ReturnHeader("MAGICAL BREATHING",{running=false;onBack()})
        SceneBanner(R.drawable.scene_observatory,"The Stardust Observatory",height=140.dp)
        PixelTitle(if(finished)"WELL DONE ✦" else if(running)cue else "Find Your Rhythm",
            color=Cyan,size=19.sp)
        Box(Modifier.fillMaxWidth().height(230.dp),contentAlignment=Alignment.Center) {
            Box(Modifier.size(203.dp).border(2.dp,PanelEdge,CircleShape).background(Cosmic,CircleShape))
            Box(Modifier.size(orbSize).border(3.dp,Cyan,CircleShape)
                .background(Brush.radialGradient(listOf(Lavender,Cyan.copy(alpha=.75f),Indigo)),CircleShape))
            PixelTitle(if(running)"${if(inhale)"IN" else "OUT"}" else "✦",color=Navy,size=22.sp)
        }
        if(running) {
            Text("${seconds/60}:${(seconds%60).toString().padStart(2,'0')} / $minutes min",color=Gold)
            Text("Follow the orb at a comfortable pace. Never force a breath or hold your breath.",
                color=Muted,fontSize=12.sp,textAlign=TextAlign.Center)
        } else if(finished) {
            Text("+55 XP · +25 gold",color=Gold,fontWeight=FontWeight.Bold)
            PixelButton("DONE",onBack,Modifier.fillMaxWidth())
        } else {
            Text("CHOOSE YOUR STYLE",color=Muted,fontSize=11.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                phases.keys.forEach { mode ->
                    FilterChip(selected=selected==mode,onClick={selected=mode},label={Text(mode)})
                }
            }
            Text("DURATION",color=Muted,fontSize=11.sp)
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                listOf(1,3,5,10).forEach { m ->
                    FilterChip(selected=minutes==m,onClick={minutes=m},label={Text("$m min")})
                }
            }
            PixelButton("START BREATHING",{seconds=0;finished=false;token=UUID.randomUUID().toString();running=true},
                Modifier.fillMaxWidth())
        }
        if(running) PixelButton("STOP EXERCISE",{running=false;seconds=0},Modifier.fillMaxWidth(),primary=false)
        Text("Stop or breathe normally at any time. Avoid this exercise if it feels uncomfortable.",
            color=Muted,fontSize=11.sp,textAlign=TextAlign.Center)
    }
}
