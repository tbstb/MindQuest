package com.mindquest.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "profile")
data class HeroEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "Traveler",
    val avatar: Int = 0,
    val xp: Int = 0,
    val gold: Int = 75,
    val totalGoldEarned: Int = 75,
    val questsCompleted: Int = 0,
    val meditationsCompleted: Int = 0,
    val mindfulMinutes: Int = 0,
    val breathingCompleted: Int = 0,
    val focusPoints: Int = 0,
    val wisdomPoints: Int = 0,
    val calmPoints: Int = 0
)

@Entity(tableName = "quests")
data class QuestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val detail: String = "",
    val category: String = "Wellness",
    val repeat: String = "Daily", // Daily, Weekly, Once
    val minutes: Int = 5,
    val xp: Int = 60,
    val gold: Int = 20,
    val completedKey: String? = null,
    val lastRewardKey: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "activity_logs")
data class ActivityLogEntity(
    @PrimaryKey val token: String,
    val contentId: String,
    val kind: String,
    val minutes: Int,
    val timestamp: Long,
    val xp: Int,
    val gold: Int
)

@Entity(tableName = "inventory")
data class InventoryEntity(
    @PrimaryKey val itemId: String,
    val quantity: Int = 1,
    val equipped: Boolean = false
)

@Entity(tableName = "journal")
data class JournalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mood: String,
    val note: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorites")
data class FavoriteEntity(@PrimaryKey val contentId: String)

@Dao
interface MindDao {
    @Query("SELECT * FROM profile WHERE id=1") fun heroFlow(): Flow<HeroEntity?>
    @Query("SELECT * FROM profile WHERE id=1") suspend fun hero(): HeroEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putHero(hero: HeroEntity)

    @Query("SELECT * FROM quests ORDER BY createdAt ASC, id ASC") fun questFlow(): Flow<List<QuestEntity>>
    @Query("SELECT * FROM quests WHERE id=:id") suspend fun quest(id: Long): QuestEntity?
    @Query("SELECT COUNT(*) FROM quests") suspend fun questCount(): Int
    @Insert suspend fun addQuests(vararg quests: QuestEntity)
    @Update suspend fun updateQuest(quest: QuestEntity)
    @Query("DELETE FROM quests WHERE id=:id") suspend fun deleteQuest(id: Long)

    @Query("SELECT * FROM activity_logs ORDER BY timestamp DESC") fun logFlow(): Flow<List<ActivityLogEntity>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertActivity(log: ActivityLogEntity): Long

    @Query("SELECT * FROM inventory ORDER BY itemId") fun inventoryFlow(): Flow<List<InventoryEntity>>
    @Query("SELECT * FROM inventory WHERE itemId=:id") suspend fun inventory(id: String): InventoryEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putInventory(item: InventoryEntity)
    @Query("UPDATE inventory SET equipped=0") suspend fun unequipAll()
    @Query("UPDATE inventory SET equipped=1 WHERE itemId=:id") suspend fun equip(id: String)

    @Query("SELECT * FROM favorites") fun favoritesFlow(): Flow<List<FavoriteEntity>>
    @Query("SELECT * FROM favorites WHERE contentId=:id") suspend fun favorite(id: String): FavoriteEntity?
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addFavorite(item: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE contentId=:id") suspend fun removeFavorite(id: String)

    @Query("SELECT * FROM journal ORDER BY timestamp DESC") fun journalFlow(): Flow<List<JournalEntity>>
    @Insert suspend fun insertJournal(entry: JournalEntity)
    @Query("DELETE FROM journal WHERE id=:id") suspend fun deleteJournal(id: Long)
}

@Database(
    entities = [HeroEntity::class, QuestEntity::class, ActivityLogEntity::class,
        InventoryEntity::class, JournalEntity::class, FavoriteEntity::class],
    version = 1, exportSchema = false
)
abstract class MindQuestDatabase : RoomDatabase() {
    abstract fun dao(): MindDao
    companion object {
        @Volatile private var db: MindQuestDatabase? = null
        fun get(context: Context): MindQuestDatabase = db ?: synchronized(this) {
            db ?: Room.databaseBuilder(context.applicationContext, MindQuestDatabase::class.java,
                "mindquest-local.db").build().also { db = it }
        }
    }
}
