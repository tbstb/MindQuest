package com.mindquest.app.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

val Context.mindSettings by preferencesDataStore(name = "mindquest_settings")

data class UserSettings(
    val onboardingDone: Boolean = false,
    val reducedMotion: Boolean = false,
    val reminders: Boolean = false,
    val streakVisible: Boolean = false,
    val sleepSoundsEnabled: Boolean = true,
    val selectedGoals: String = "Feel calmer",
    val experienceLevel: String = "New to meditation",
    val preferredMinutes: Int = 5,
    val startingWorld: String = "Moonlight Village"
)

class SettingsStore(private val context: Context) {
    private object K {
        val ONBOARDED = booleanPreferencesKey("onboarded")
        val MOTION = booleanPreferencesKey("reduced_motion")
        val REMINDERS = booleanPreferencesKey("reminders")
        val STREAK = booleanPreferencesKey("show_streak")
        val SOUND = booleanPreferencesKey("sleep_sound")
        val GOALS = stringPreferencesKey("goals")
        val EXP = stringPreferencesKey("experience")
        val LENGTH = intPreferencesKey("preferred_minutes")
        val WORLD = stringPreferencesKey("starting_world")
    }
    val flow = context.mindSettings.data.map { p ->
        UserSettings(
            onboardingDone = p[K.ONBOARDED] ?: false,
            reducedMotion = p[K.MOTION] ?: false,
            reminders = p[K.REMINDERS] ?: false,
            streakVisible = p[K.STREAK] ?: false,
            sleepSoundsEnabled = p[K.SOUND] ?: true,
            selectedGoals = p[K.GOALS] ?: "Feel calmer",
            experienceLevel = p[K.EXP] ?: "New to meditation",
            preferredMinutes = p[K.LENGTH] ?: 5,
            startingWorld = p[K.WORLD] ?: "Moonlight Village"
        )
    }
    suspend fun completeOnboarding(goals:List<String> = emptyList(),
                                   experience:String = "New to meditation",
                                   duration:Int = 5, world:String = "Moonlight Village") {
        context.mindSettings.edit {
            it[K.ONBOARDED] = true
            it[K.GOALS] = goals.joinToString("|").ifBlank { "Feel calmer" }
            it[K.EXP] = experience
            it[K.LENGTH] = duration.coerceIn(1,60)
            it[K.WORLD] = world
        }
    }
    suspend fun setReducedMotion(v: Boolean) = context.mindSettings.edit { it[K.MOTION] = v }
    suspend fun setReminders(v: Boolean) = context.mindSettings.edit { it[K.REMINDERS] = v }
    suspend fun setStreak(v: Boolean) = context.mindSettings.edit { it[K.STREAK] = v }
    suspend fun setSleepSound(v: Boolean) = context.mindSettings.edit { it[K.SOUND] = v }
}
