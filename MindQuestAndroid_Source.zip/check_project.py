"""Static project checks; does not replace an Android SDK compilation or device test."""
from pathlib import Path
import re, struct, wave, xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
main=root/'app/src/main'
source='\n'.join(f.read_text(encoding='utf-8') for f in (main/'java').rglob('*.kt'))
files=list((main/'java').rglob('*.kt'))
assert len(files)>=8, 'Expected native Kotlin sources'
for kind,extension,location in [('drawable','.png','drawable-nodpi'),('raw','.wav','raw'),('mipmap','.png','mipmap-hdpi')]:
    refs=set(re.findall(r'R\.'+kind+r'\.([a-z0-9_]+)',source))
    for name in sorted(refs):
        assert (main/'res'/location/(name+extension)).exists(), f'Missing {kind} {name}'
    print(f'OK {len(refs)} referenced {kind} resources')
for image in (main/'res'/'drawable-nodpi').glob('*.png'):
    with image.open('rb') as fh:
        head=fh.read(24)
    assert head[:8]==b'\x89PNG\r\n\x1a\n',f'Not PNG: {image}'
    w,h=struct.unpack('>II',head[16:24]);assert w>=48 and h>=48
print('OK original drawable PNGs:',len(list((main/'res'/'drawable-nodpi').glob('*.png'))))
for wav in (main/'res'/'raw').glob('*.wav'):
    with wave.open(str(wav)) as audio:
        assert audio.getnchannels()==1
        assert audio.getframerate()==16000
        assert audio.getnframes()/audio.getframerate()>=25
print('OK offline sound beds:',len(list((main/'res'/'raw').glob('*.wav'))))
ET.parse(main/'AndroidManifest.xml')
ET.parse(main/'res/values/styles.xml')
assert (root/'.github/workflows/android-build.yml').exists()
assert (root/'app/build.gradle.kts').exists()
assert 'onGetSession(' in source
assert 'withTransaction {' in source
print('OK Android manifest, theme, Gradle, Media3 service, Room transactions')
print('NOTE: SDK build, installation, runtime tests and release signing remain UNVERIFIED.')
