"""Generate wholly original, deterministic pixel illustrations + ambient sound beds.
Requires Pillow and numpy. Asset source included so artwork can be modified.
"""
from PIL import Image, ImageDraw
import random, math, os, wave
import numpy as np
ROOT=os.path.dirname(__file__)
OUT=os.path.join(ROOT,'app/src/main/res/drawable-nodpi')
RAW=os.path.join(ROOT,'app/src/main/res/raw')
os.makedirs(OUT,exist_ok=True); os.makedirs(RAW,exist_ok=True)

def px(im, path, scale=4):
    im.resize((im.width*scale, im.height*scale),Image.Resampling.NEAREST).save(os.path.join(OUT,path+'.png'))
def rect(d,box,color): d.rectangle(box, fill=color)
def poly(d, pts, fill): d.polygon(pts,fill=fill)
def line(d,pts,fill,width=1): d.line(pts,fill=fill,width=width)
def star(d,x,y,c):
    rect(d,(x-2,y,x+2,y),c); rect(d,(x,y-2,x,y+2),c); d.point((x-3,y),fill=c); d.point((x+3,y),fill=c)
def tree(d,x,y,s,pal):
    trunk=pal['trunk']; leaf=pal['leaf']; hi=pal['leaf2'];
    rect(d,(x-2*s,y-4*s,x+2*s,y+8*s),trunk)
    for k, w in [(0,12),(1,10),(2,7)]:
        yt=y-(k*8+4)*s
        poly(d,[(x,yt-10*s),(x-w*s,yt+8*s),(x+w*s,yt+8*s)],leaf if k%2 else hi)
        line(d,[(x,yt-9*s),(x-int(w*.75)*s,yt+5*s)],hi)
def house(d,x,y,sc):
    rect(d,(x-18*sc,y-11*sc,x+18*sc,y+17*sc),'#a87c83')
    rect(d,(x-15*sc,y-9*sc,x+15*sc,y+15*sc),'#dfb78e')
    poly(d,[(x-24*sc,y-11*sc),(x,y-29*sc),(x+25*sc,y-11*sc)],'#563954')
    line(d,[(x-23*sc,y-11*sc),(x,y-29*sc),(x+24*sc,y-11*sc)],'#bb8cba',2)
    rect(d,(x-3*sc,y+4*sc,x+5*sc,y+16*sc),'#68465a')
    rect(d,(x-12*sc,y-6*sc,x-6*sc,y+1*sc),'#fff2a3'); rect(d,(x+7*sc,y-6*sc,x+13*sc,y+1*sc),'#fff2a3')
    rect(d,(x-12*sc,y-6*sc,x-11*sc,y+1*sc),'#bc7949')
def bloom(d,x,y,c):
    for ax,ay in [(-2,0),(2,0),(0,-2),(0,2)]:d.rectangle((x+ax-1,y+ay-1,x+ax+1,y+ay+1),fill=c)
    d.point((x,y),fill='#f5cb62')

PALETTES={
 'village': dict(top='#171b42',bottom='#8e5b9e',far='#51518f',near='#394c80',ground='#214b5e',leaf='#1b5260',leaf2='#32777d',trunk='#413557',water='#4d7ab2',accent='#ffd9aa',moon='#f7e8dc'),
 'forest':dict(top='#152b4b',bottom='#6a78b0',far='#55699a',near='#2e567a',ground='#214e58',leaf='#164c57',leaf2='#368374',trunk='#483e5a',water='#3a8a9d',accent='#ffd1a0',moon='#f5e0c3'),
 'lake':dict(top='#26204e',bottom='#af79a7',far='#7161ac',near='#4f6a9a',ground='#264c6b',leaf='#275c70',leaf2='#438e96',trunk='#4c3861',water='#4d81bc',accent='#ffc4bc',moon='#fff1dc'),
 'castle':dict(top='#19193b',bottom='#795f96',far='#5b5489',near='#464c84',ground='#284463',leaf='#285368',leaf2='#5c8a8c',trunk='#493e62',water='#4a79a8',accent='#e9b7ed',moon='#e8e7ff'),
 'meadow':dict(top='#3f427e',bottom='#d699a6',far='#8880bc',near='#5b7b9e',ground='#53687a',leaf='#486e71',leaf2='#7da391',trunk='#73526c',water='#82acbe',accent='#ffe0a0',moon='#ffedcc'),
 'observatory':dict(top='#10142b',bottom='#5b4486',far='#42447e',near='#343b69',ground='#252f53',leaf='#293c68',leaf2='#4d6a91',trunk='#37324f',water='#426692',accent='#98ddf1',moon='#f1e8ff'),
 'sky':dict(top='#314f91',bottom='#a783c7',far='#7b79bf',near='#707cb2',ground='#4c638e',leaf='#376c87',leaf2='#7caeba',trunk='#615377',water='#81bdd4',accent='#fff1c7',moon='#fff7da'),
 'garden':dict(top='#201c48',bottom='#9e70b4',far='#6f61a9',near='#526998',ground='#345877',leaf='#305c70',leaf2='#538c83',trunk='#503d60',water='#688fbe',accent='#f9ccdf',moon='#fff4fa'),
}

def scene(name, seed):
    p=PALETTES[name]; r=random.Random(seed); W,H=240,148
    im=Image.new('RGB',(W,H),p['top']); d=ImageDraw.Draw(im)
    ca=np.array(tuple(int(p['top'][i:i+2],16) for i in (1,3,5)))
    cb=np.array(tuple(int(p['bottom'][i:i+2],16) for i in (1,3,5)))
    for y in range(H):
        t=min(1,y/115)
        col=tuple(np.uint8(ca*(1-t)+cb*t))
        d.line((0,y,W,y),fill=col)
    for _ in range(36):
        x=r.randrange(W);y=r.randrange(3,76)
        if r.random()<.26:star(d,x,y,r.choice(['#f8d6ba','#a6dcf2','#cfaef5']))
        else:d.point((x,y), fill='#c4c3e7')
    d.ellipse((180,13,199,32),fill=p['moon'])
    d.ellipse((184,13,203,29),fill=p['top'])
    poly(d,[(0,110),(23,65),(45,92),(75,42),(107,91),(138,55),(165,94),(195,43),(240,94),(240,144),(0,144)],p['far'])
    for x,y in [(75,42),(195,43)]:poly(d,[(x-7,y+11),(x,y),(x+9,y+12)],'#bfb6d5')
    poly(d,[(0,118),(26,91),(64,116),(99,83),(136,114),(161,85),(209,124),(240,96),(240,H),(0,H)],p['near'])
    poly(d,[(0,122),(20,118),(54,124),(86,116),(117,124),(155,115),(191,120),(240,110),(240,H),(0,H)],p['ground'])
    poly(d,[(89,119),(158,113),(200,122),(240,125),(240,H),(53,H)],p['water'])
    for y in range(123,H,5):
        for _ in range(9):
            x=r.randrange(75,236);d.line((x,y,x+r.randint(2,10),y),fill=r.choice(['#83a7d2','#a5bee0','#598ab6']))
    # landmark, different for each biome
    if name=='castle':
        for x,yt in [(156,68),(179,52),(200,74)]:
            rect(d,(x,yt,x+16,116),'#bd9db5');poly(d,[(x-4,yt),(x+8,yt-22),(x+20,yt)],'#624e88')
            rect(d,(x+5,yt+13,x+10,yt+22),'#ffe4a2')
        rect(d,(158,95,216,117),'#d3a9b1')
    elif name=='observatory':
        rect(d,(172,83,209,112),'#8a92bd'); d.ellipse((171,66,210,99),fill='#d7b7de');d.ellipse((179,72,202,96),fill='#7a66ae')
        rect(d,(189,64,193,73),'#dbe8fb')
    elif name=='sky':
        for x,y in [(31,54),(157,72)]:
            d.ellipse((x,y,x+61,y+16),fill='#ddd4e8');poly(d,[(x+9,y+8),(x+47,y+8),(x+30,y+26)],'#4d6b8a')
    elif name=='garden':
        rect(d,(166,81,169,114),'#eacde0');rect(d,(192,81,195,114),'#eacde0');d.arc((165,65,196,96),180,360,fill='#fce1e7',width=3)
    else:
        house(d,172,99,1)
    for x,s in [(8,1),(33,1),(53,1),(225,1)]:tree(d,x,113+(x%3)*5,s,p)
    for _ in range(40):
        x=r.randrange(W);y=r.randrange(120,147)
        if not(65 <x<220 and y>130):bloom(d,x,y,r.choice(['#efa2c2','#eac5fb','#f8d59e','#b0e6e1']))
    px(im,f'scene_{name}',4)
    return im
for n,i in zip(PALETTES,range(8)):scene(n,2027+i)
# Splash art: custom 9:16 crop of original village with a foreground traveler, lantern, and cat.
src=Image.open(os.path.join(OUT,'scene_village.png')).resize((240,148),Image.Resampling.NEAREST)
im=Image.new('RGB',(240,330),'#161735');d=ImageDraw.Draw(im)
for y in range(0,330,148):im.paste(src,(0,y))
d=ImageDraw.Draw(im)
d.rectangle((0,153,239,183),fill='#211c45')
d.rectangle((0,0,239,12),fill='#161735')
for x,y in [(26,20),(65,27),(178,32),(202,18),(33,183),(199,190)]:star(d,x,y,'#f5d797')
# traveler from back
rect(d,(65,235,95,270),'#824c63');rect(d,(74,213,94,245),'#dbab89');rect(d,(71,210,95,223),'#403253')
rect(d,(66,228,78,258),'#402c52');rect(d,(76,268,82,280),'#2b2b4e');rect(d,(87,267,93,280),'#2b2b4e')
rect(d,(99,246,116,270),'#efdee1');poly(d,[(100,247),(103,239),(109,247),(113,238),(116,248)],'#efdee1')
rect(d,(107,255,109,257),'#26213b')
d.ellipse((7,280,239,350),fill='#284f66')
for x,y in [(24,289),(40,305),(140,303),(164,290),(219,306)]:bloom(d,x,y,'#d9a4df')
px(im,'splash_scene',4)
# Avatar icons using original tiny character design and multiple variants.
def avatar(i):
  hair=['#51324f','#9383bd','#caa56e','#d66d70','#33334e','#70b3c1']
  skin=['#dba584','#ab715c','#f2c7a0','#bc8264','#e5b394','#9e674f']
  outfit=['#79b7b0','#ad7cb9','#b88e5c','#bf7591','#80a1ce','#69ab9c']
  im=Image.new('RGBA',(48,48),(0,0,0,0));d=ImageDraw.Draw(im)
  d.ellipse((3,2,44,44), fill='#4b447b',outline='#a68ed1',width=2)
  rect(d,(14,29,34,43),outfit[i]);rect(d,(17,39,22,45),'#373451');rect(d,(27,39,32,45),'#373451')
  rect(d,(13,13,35,33),skin[i]);rect(d,(11,10,36,18),hair[i]);rect(d,(11,16,16,29),hair[i]);rect(d,(32,15,37,28),hair[i])
  for x in (20,29):rect(d,(x,24,x+2,26),'#28233d')
  rect(d,(24,29,26,30),'#a55c69');d.point((18,20),fill='#eac6bc')
  if i%2==1:rect(d,(15,9,30,13),'#e0bddd')
  px(im,f'avatar_{i}',4)
for i in range(6):avatar(i)
# Inventory icon art, 36px canvas
icons=['cloak','crystal','cat','potion','key','lantern','blossom','moon','staff','crown','scroll','cloud']
for idx,name in enumerate(icons):
  im=Image.new('RGBA',(40,40),(0,0,0,0));d=ImageDraw.Draw(im)
  if name=='cloak':
    poly(d,[(15,8),(25,8),(32,34),(8,34)],'#b66b85');rect(d,(16,8,24,17),'#e49fa5');line(d,[(20,11),(20,33)],'#783e68',2)
  elif name=='crystal':
    poly(d,[(20,2),(31,15),(25,35),(14,35),(9,16)],'#71dfef');poly(d,[(20,2),(20,35),(9,16)],'#b7ffff');line(d,[(20,2),(31,15),(25,35)],'#e9f7ff')
  elif name=='cat':
    poly(d,[(7,17),(12,5),(19,14),(27,5),(33,18),(31,32),(9,32)],'#f6d6e4');rect(d,(12,21,15,24),'#34334b');rect(d,(25,21,28,24),'#34334b')
  elif name=='potion':
    rect(d,(17,4,24,12),'#cfb4e8');rect(d,(12,11,29,34),'#e8d5f5');rect(d,(14,20,27,32),'#e87cae');rect(d,(19,4,22,7),'#f8eeb4')
  elif name=='key':
    d.ellipse((6,7,20,21),outline='#f7ce77',width=4);line(d,[(18,19),(32,32)],'#f7ce77',4);rect(d,(24,26,29,29),'#f7ce77')
  elif name=='lantern':
    rect(d,(14,9,27,32),'#614669');rect(d,(16,13,25,28),'#fff0a1');line(d,[(16,7),(25,7)],'#ce9d78',2);d.arc((15,3,26,15),180,360,fill='#dfbe8e',width=2)
  elif name=='blossom':
    for x,y in [(12,14),(26,14),(12,27),(26,27)]:d.ellipse((x-5,y-5,x+5,y+5),fill='#e2a0cc')
    d.ellipse((16,16,23,23),fill='#f7da84')
  elif name=='moon':
    d.ellipse((7,5,33,34),fill='#f7e8bc');d.ellipse((14,1,36,29),fill='#392c63')
  elif name=='staff':
    line(d,[(16,35),(27,7)],'#bca17b',4);d.ellipse((20,3,34,17),fill='#95e1df');d.ellipse((24,6,29,11),fill='#e6fafa')
  elif name=='crown':
    poly(d,[(7,14),(13,23),(19,9),(25,23),(33,12),(30,31),(10,31)],'#f6ca68');rect(d,(11,26,29,29),'#e0a345')
  elif name=='scroll':
    rect(d,(11,8,31,32),'#e3ccab');d.ellipse((7,7,14,14),fill='#caa676');d.ellipse((7,28,14,35),fill='#caa676');line(d,[(17,16),(27,16)],'#83607a');line(d,[(17,21),(27,21)],'#83607a')
  else:
    d.ellipse((5,16,21,30),fill='#cde5f1');d.ellipse((15,7,31,30),fill='#e9f5fb');rect(d,(6,24,33,31),'#d7ebf7')
  px(im,f'item_{name}',4)
# app icon artwork
ico=Image.new('RGB',(128,128),'#191b3f');d=ImageDraw.Draw(ico)
d.ellipse((9,9,119,119),fill='#34305c',outline='#bea0e9',width=5)
poly(d,[(64,11),(84,42),(64,68),(44,42)],'#89e9f6')
poly(d,[(64,11),(64,68),(44,42)],'#d0b5fa')
for x,y in [(31,31),(98,29),(27,83),(101,88)]:star(d,x,y,'#ffdda1')
poly(d,[(20,98),(48,69),(65,94),(83,68),(112,98)],'#6479a5')
rect(d,(22,98,109,105),'#528282')
ico.resize((512,512),Image.Resampling.NEAREST).save(os.path.join(ROOT,'app/src/main/res/mipmap-hdpi/ic_launcher.png'))
# 3 original looping ambient beds encoded to reasonable-size mono PCM WAV
SAMPLE_RATE=16000
seconds=36
rng=np.random.default_rng(29)
t=np.arange(SAMPLE_RATE*seconds,dtype=np.float64)/SAMPLE_RATE

def wavefile(name,samples):
    samples=np.asarray(samples);samples=np.tanh(samples*1.2)*.66
    pcm=(samples*32767).astype(np.int16)
    with wave.open(os.path.join(RAW,f'{name}.wav'),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(SAMPLE_RATE);w.writeframes(pcm.tobytes())
# Layered soft tones with slow tremolo and a low gentle riverlike hiss
melody=np.zeros_like(t)
for f,amp,period in [(196,.17,19.0),(293.66,.10,22),(392,.05,13),(261.63,.10,30)]:
    melody+=amp*np.sin(2*np.pi*f*t)*((np.sin(2*np.pi*t/period)+1)/2)**2
noise=rng.normal(0,1,len(t));smooth=np.convolve(noise,np.ones(21)/21,mode='same')
wavefile('moonlit_ambient',melody+smooth*.05)
# Airy rain, gentle slow evolving breeze
r=rng.normal(0,1,len(t));river=np.convolve(r,np.ones(31)/31,mode='same')
wavefile('gentle_rain',river*.42+0.075*np.sin(2*np.pi*110*t)*(0.4+0.3*np.sin(2*np.pi*t/9)))
# dreamy chimes
chime=np.zeros_like(t)
for tt in np.arange(0,36,2.7):
    start=int(tt*SAMPLE_RATE);end=min(len(t),start+int(3*SAMPLE_RATE));local=np.arange(end-start)/SAMPLE_RATE
    freq=[349.23,440,523.25,587.33,659.25][int(tt/2.7)%5]
    chime[start:end]+=np.exp(-local*1.7)*(.14*np.sin(2*np.pi*freq*local)+.04*np.sin(2*np.pi*freq*2*local))
wavefile('stardust_chimes',chime+smooth*.06)
print('generated', len(os.listdir(OUT)),'art pieces and',len(os.listdir(RAW)),'audio beds')
# Original miniature pixel navigation glyphs (rather than platform system icons)
for name in ['home','quests','meditate','adventure','profile']:
    im=Image.new('RGBA',(24,24),(0,0,0,0));d=ImageDraw.Draw(im)
    if name=='home':
        poly(d,[(2,11),(12,2),(22,11)],'#f6d486');rect(d,(5,11,19,22),'#a57a8f');rect(d,(10,15,14,22),'#ffe7a6')
    elif name=='quests':
        line(d,[(4,4),(18,20)],'#f0e6e4',3);line(d,[(20,3),(5,19)],'#a5d8e3',3)
        rect(d,(2,2,6,6),'#f7cb76');rect(d,(17,1,21,5),'#f7cb76')
    elif name=='meditate':
        for p in [[(12,3),(7,13),(12,18),(17,13)],[(3,10),(9,9),(12,19)],[(21,10),(15,9),(12,19)]]:
            poly(d,p,'#e1a9e2')
        d.ellipse((8,8,15,17),fill='#f0c2d8');line(d,[(2,20),(22,20)],'#7ed4be',2)
    elif name=='adventure':
        poly(d,[(3,5),(10,2),(16,5),(21,3),(21,20),(15,21),(9,18),(3,21)],'#bcb4e3')
        line(d,[(10,2),(9,18)],'#8073b7');line(d,[(16,5),(15,21)],'#8073b7')
        star(d,13,11,'#f9d37d')
    else:
        d.ellipse((3,2,21,22),fill='#7f6aaf',outline='#e6c9aa',width=2)
        rect(d,(7,8,17,18),'#d9a786');rect(d,(6,6,18,10),'#503454')
        rect(d,(9,12,10,13),'#25223d');rect(d,(15,12,16,13),'#25223d')
    px(im,f'nav_{name}',4)
print('generated original navigation icon set')
