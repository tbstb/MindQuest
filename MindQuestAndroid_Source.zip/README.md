# MindQuest — Native Android Pixel RPG + Meditation

**Status:** Source project prepared. **APK is not included or verified.** The authoring environment had Java 21 and Kotlin, but **no Android SDK, Android Gradle plugin dependencies, or Gradle distribution**, and had no direct network access. An honest local `assembleDebug` build and device install test were therefore impossible. This repository includes a GitHub Actions build workflow to perform the actual Android compilation.

## Important scope note

This is an **original, offline-first working-sample implementation**, not a literal reimplementation of the Calm app or a released commercial-quality product. The core architecture, screens, storage, sample audio, quests, rewards, and navigation are present as native Kotlin/Compose source. **Compilation, runtime stability, playback on specific devices, and production readiness are NOT yet verified.** Some advanced features from the specification remain future work.

### Included

- Android-native Kotlin + Jetpack Compose five-tab mobile app (Home, Quests, Meditate, Adventure, Profile)
- Five-part RPG onboarding, character portrait/name choices, goal and pace preferences saved to DataStore
- Nine guided wellness meditations plus two original sleep-story demos and an unguided timer, using local Android TTS voices for scripts and included original ambient audio
- Media3 ExoPlayer background audio `MediaSessionService`, lock-screen media controls, repeatable original offline WAV sound beds, mini-player, pause/resume, sleep-session end fade-out
- Room-persisted quests, editing, completion/undo, daily/weekly/one-time cycles, and transaction-protected once-per-period reward accounting
- Persisted XP, level, fantasy attributes, gold, inventory, cosmetic item shop and equip actions, world-unlock milestones
- Persisted mood journal, Android Sharesheet text export and delete, analytics activity grid, achievements
- Gentle timed breathing exercise, optional periodic reminder via WorkManager, notification permission prompt, reduced-motion toggle and local-data reset
- 32 original pixel-art PNG resources, three original synthesized WAV sound beds, and full Python source that generates these assets
- GitHub Actions APK workflow and basic unit tests for progression/calendaring rules

### Not yet implemented / not claimed

- A compiled, installed, or emulator-tested APK; signed release build / app-store submission
- Full premium subscription and Google Play Billing (the included sample is completely free, with no payment flows)
- Cloud account, synchronization, login, server backup, subscription management
- Offline audio *downloads* (sample audio is already bundled offline), playlists, large production narration catalog
- Full production sleep-story recordings by a human narrator (original text uses device Text-to-Speech)
- Full-featured audio session resurrection after OS process death or independently scheduled session-completion reward while app is force-stopped
- Advanced accessibility audit, UI tests on multiple phone sizes, battery benchmark and crash telemetry
- True bespoke pixel-display typeface (monospace title fallback is bundled via platform fonts; no third-party fonts redistributed)

## Build on any machine with Android Studio

1. Open the directory in Android Studio (JDK 17 recommended).
2. Let Gradle sync/download its dependencies; use Android SDK 35.
3. Run **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK should appear at `app/build/outputs/apk/debug/app-debug.apk` if compilation succeeds.
5. Test on Android 8.0+ (API 26+), including Android 13/14/15 background audio and notification prompts.

> The repository does not include a Gradle wrapper JAR or executable, because the authoring environment could not download an official Gradle distribution. Android Studio's built-in Gradle integration or the `gradle` CLI installed by the CI workflow is used instead.

## Build using **only an Android phone and GitHub**

The easiest reproducible APK workflow is included in `.github/workflows/android-build.yml`.

1. Extract `MindQuestAndroid_Source.zip` on your Android device.
2. Create a private GitHub repository named `MindQuest`.
3. Upload/commit this project's files to the repo, preserving the nested `app/` and `.github/workflows/` structure. One way entirely on Android is the Termux terminal with Git + GitHub CLI (see `BUILD_ON_ANDROID_PHONE.md`).
4. Push to the `main` branch (or use the Actions tab > **Build MindQuest Android APK** > **Run workflow**).
5. Wait for a **successful** workflow; open the run > **Artifacts** > **MindQuest-debug-APK**.
6. Download and unzip the artifact on Android. The file is `app-debug.apk`.
7. Open it to install, allowing trusted APK installation in Android settings for your file app if prompted.

If the CI workflow fails, read the exact build logs; this repository has not been compiled in the authoring environment, so corrections may be required. Never relabel a source ZIP as an APK.

## Architecture

- `app/src/main/java/com/mindquest/app/MainViewModel.kt`: app state, reward completion, audio-session timer
- `data/Database.kt`: Room entities and DAOs
- `data/MindRepository.kt`: transactional quest/reward/inventory operations
- `data/Settings.kt`: DataStore preferences
- `model/Catalog.kt`: authored original guided text, content/quest/shop catalogs, level math
- `audio/`: background playback service, controller, device TTS voice guidance
- `ui/`: theme and interactive Compose screens
- `notifications/`: optional periodic reminder worker
- `create_assets.py`: deterministic generator for original sprites and audio

## Privacy

All personal content is stored in the app-private Room DB and DataStore. No ad, tracking, cloud, analytics, subscription, or account SDK is included. Android device-level file encryption depends on device configuration. Journals are **not separately encrypted with a user passcode**. Export shares selected text with a user-chosen application. Uninstalling removes app-private data because backups are disabled.

## Audio and art

All generated art and ambient sounds in this repository are new algorithmic works created for MindQuest. Device TTS voices are supplied by the installed Android voice engine, not bundled as proprietary recordings. The app is visually inspired by *a genre*, not copied UI artwork from Calm, Habitica, or another developer.

## Safety and experience

Breathing guidance is comfortable and optional; do not force breathing. Users can skip or end sessions without punishment. Fantasy points do not indicate mental-health, fitness or clinical status. MindQuest is not a medical device or therapy substitute.
